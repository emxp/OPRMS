package com.example.new1.Model.Administration;

import com.example.new1.Model.Academic.College;
import com.example.new1.Model.Academic.Staff;

import javax.persistence.*;

@Entity
public class VicePresident {


    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    @OneToOne
    @JoinColumn(name = "adminStaff_id", referencedColumnName = "id")
    private AdminStaff adminStaff;
    @OneToOne
    @JoinColumn(name = "office_id", referencedColumnName = "id")
    private VPOffice vpOffice;

    public VicePresident() {
    }

    public VicePresident(AdminStaff adminStaff, VPOffice vpOffice) {
        this.adminStaff = adminStaff;
        this.vpOffice = vpOffice;
    }

    public int getId() {
        return id;
    }

    public AdminStaff getAdminStaff() {
        return adminStaff;
    }

    public void setAdminStaff(AdminStaff adminStaff) {
        this.adminStaff = adminStaff;
    }

    public VPOffice getVpOffice() {
        return vpOffice;
    }

    public void setVpOffice(VPOffice vpOffice) {
        this.vpOffice = vpOffice;
    }
}
