package com.example.new1.Repository;

import com.example.new1.Model.Administration.President;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PresidentRepository extends JpaRepository<President, Integer> {
    President findById(int id);
}
