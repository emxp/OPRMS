package com.example.new1.Model.planRelated;

import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Entity
@Table(name = "plan5")
public class Plan5 {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @NotEmpty(message = "እቅድ መፃፍ አለበት!")
//    @Column(columnDefinition = "TEXT")
    private String content;

    @NotNull(message = "ቀኑን ያስገቡ!")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate startDate = LocalDate.of(2018, 11, 12);

    @NotNull(message = "ቀኑን ያስገቡ!")
    @Future(message = "ቀኑ መቅደም አለበት!")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate endDate = LocalDate.of(2018, 11, 12);

    @Column(columnDefinition = "TEXT")
    private String status;

    @Column(name = "plan_id", insertable = false, updatable = false)        //insertable and updatable must be false so that it keeps using the normal value of planId that it gets during the new Plan Creation;
    private int planId;

    public Plan5(String content, LocalDate startDate, LocalDate endDate, String status) {
        this.content = content;
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
    }

    public Plan5() {
    }

    public int getId() {
        return id;
    }

    public String getContent() {
        return content;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public String getStatus() {
        return status;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getPlanId() {
        return planId;
    }

    public void setPlanId(int planId) {
        this.planId = planId;
    }
}
