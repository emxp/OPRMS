package com.example.new1.Repository.general;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class ScrollRepository {
    private List<String> whichOneIsClicked = new ArrayList<>();

    public ScrollRepository() {
    }

    public List<String> getWhichOneIsClicked() {
        populateWhichOneIsClicked();
        return whichOneIsClicked;
    }

    public void setWhichOneIsClicked(List<String> whichOneIsClicked) {
        this.whichOneIsClicked = whichOneIsClicked;
    }

    public List<String> populateWhichOneIsClicked() {
        whichOneIsClicked.clear();
        for (int r = 0; r<7; r++)
            whichOneIsClicked.add("");
        return whichOneIsClicked;
    }

    public List<String> setTheClickedValue(int pageOneToFiveSent, int pageDevSent, int pageDevReceived, int pageDepHeadSent, int pageDepHeadReceived, int pageDeanSent, int pageDeanReceived) {
        if (pageOneToFiveSent != 1) {
            whichOneIsClicked.set(0, "theClickedBtn");
        } else if (pageDevSent != 1) {
            whichOneIsClicked.set(1, "theClickedBtn");
        } else if (pageDevReceived != 1) {
            whichOneIsClicked.set(2, "theClickedBtn");
        } else if (pageDepHeadSent != 1) {
            whichOneIsClicked.set(3, "theClickedBtn");
        } else if (pageDepHeadReceived != 1) {
            whichOneIsClicked.set(4, "theClickedBtn");
        } else if (pageDeanSent != 1){
            whichOneIsClicked.set(5, "theClickedBtn");
        } else if (pageDeanReceived != 1){
            whichOneIsClicked.set(6, "theClickedBtn");
        }
        return whichOneIsClicked;
    }

}
