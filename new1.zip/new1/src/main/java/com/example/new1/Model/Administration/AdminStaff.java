package com.example.new1.Model.Administration;

import com.example.new1.Model.Academic.Department;

import javax.persistence.*;

@Entity
public class AdminStaff {


    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String uniId;
    private String first_Name;
    private String middle_Name;
    private String last_Name;
    private String acca_Status;
    private String userName;
    private String password;

    @ManyToOne
    @JoinColumn(name = "directorate_id", referencedColumnName = "id")
    private Directorate directorate;

    public AdminStaff() {
    }

    public AdminStaff(String uniId, String first_Name, String middle_Name, String last_Name, String acca_Status, String userName, String password, Directorate directorate) {
        this.uniId = uniId;
        this.first_Name = first_Name;
        this.middle_Name = middle_Name;
        this.last_Name = last_Name;
        this.acca_Status = acca_Status;
        this.userName = userName;
        this.password = password;
        this.directorate = directorate;
    }

    public int getId() {
        return id;
    }

    public String getUniId() {
        return uniId;
    }

    public void setUniId(String uniId) {
        this.uniId = uniId;
    }

    public String getFirst_Name() {
        return first_Name;
    }

    public void setFirst_Name(String first_Name) {
        this.first_Name = first_Name;
    }

    public String getMiddle_Name() {
        return middle_Name;
    }

    public void setMiddle_Name(String middle_Name) {
        this.middle_Name = middle_Name;
    }

    public String getLast_Name() {
        return last_Name;
    }

    public void setLast_Name(String last_Name) {
        this.last_Name = last_Name;
    }

    public String getAcca_Status() {
        return acca_Status;
    }

    public void setAcca_Status(String acca_Status) {
        this.acca_Status = acca_Status;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Directorate getDirectorate() {
        return directorate;
    }

    public void setDirectorate(Directorate directorate) {
        this.directorate = directorate;
    }

    public String getFullName(){
        return first_Name + " " + middle_Name + " " + last_Name;
    }

    public String getFullNameAndID(){
        return first_Name + " " + middle_Name + " " + last_Name + " - ( " + uniId + " ) ";
    }

}
