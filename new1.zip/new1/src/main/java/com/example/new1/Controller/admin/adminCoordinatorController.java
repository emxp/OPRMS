package com.example.new1.Controller.admin;


import com.example.new1.Model.Academic.Department;
import com.example.new1.Model.Academic.Coordinator;
import com.example.new1.Model.Academic.DepartmentHead;
import com.example.new1.Model.Academic.Staff;
import com.example.new1.Model.Security.Role;
import com.example.new1.Model.Security.Users;
import com.example.new1.Repository.CoordinatorRepository;
import com.example.new1.Repository.CoordinatorRepository;
import com.example.new1.Repository.DepartmentRepository;
import com.example.new1.Repository.Security.RoleRepository;
import com.example.new1.Repository.Security.UsersRepository;
import com.example.new1.Repository.StaffRepository;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping(value = "/admin")
@PreAuthorize("hasAnyRole('ADMIN')")
public class adminCoordinatorController {

    @Autowired
    private CoordinatorRepository coordinatorRepository;
    @Autowired
    private DepartmentRepository departmentRepository;
    @Autowired
    private StaffRepository staffRepository;
    @Autowired
    private UsersRepository usersRepository;
    @Autowired
    private RoleRepository roleRepository;

    @RequestMapping("/coordinators")
    public String listCoordinators(ModelMap modelMap){
        List<Coordinator> allCoordinators = coordinatorRepository.findAllByOrOrderByDepartmentAsc();
        modelMap.put("coordinators", allCoordinators);
        return "admin/adminCoordinator";
    }

    @RequestMapping(value = "/addCoordinator")
    public String addCoordinator(Model model){
        List<Department> departments = getNonCoordinatorDepartments();
        List<Staff> staffs = getNonCoordinatorStaffs();
        if(departments.isEmpty()){
            List<Coordinator> allCoordinators = coordinatorRepository.findAllByOrOrderByDepartmentAsc();
            model.addAttribute("coordinators", allCoordinators);
            model.addAttribute("isEmpty", true);
            return "admin/adminCoordinator";
        }else if(staffs.isEmpty()){
            List<Coordinator> allCoordinators = coordinatorRepository.findAllByOrOrderByDepartmentAsc();
            model.addAttribute("coordinators", allCoordinators);
            model.addAttribute("isStaffEmpty", true);
            return "admin/adminCoordinator";
        }else {
            model.addAttribute("departments", departments);
            model.addAttribute("staffs", staffs);
            model.addAttribute("coordinator", new Coordinator());
            model.addAttribute("isEdit", false);
            return "admin/editCoordinator";
        }
    }

    public List<Department> getNonCoordinatorDepartments(){
        List<Department> departments = departmentRepository.findAllByOrderByDep_NameAsc();
        List<Coordinator> coordinators = coordinatorRepository.findAll();
        List<Department> coordinatorDepartment = new ArrayList<>();
        for (int i=0; i<coordinators.size(); i++){
            coordinatorDepartment.add(coordinators.get(i).getDepartment());
        }
        for (int i=0; i<departments.size(); i++) {
            if(coordinatorDepartment.contains(departments.get(i))){
                departments.remove(departments.get(i));
                i--;        //because when item remove the structure of list is changed. so we have to move back at every remove!
            }
        }
        return departments;
    }
    public List<Staff> getNonCoordinatorStaffs(){
        List<Staff> staffs = staffRepository.findAllByOrderByFirst_NameAsc();
        List<Coordinator> coordinators = coordinatorRepository.findAll();
        List<Staff> coordinatorStaff = new ArrayList<>();
        for (int i=0; i<coordinators.size(); i++){
            coordinatorStaff.add(coordinators.get(i).getStaff());
        }
        for (int i=0; i<staffs.size(); i++) {
            if(coordinatorStaff.contains(staffs.get(i))){
                staffs.remove(staffs.get(i));
                i--;        //because when item remove the structure of list is changed. so we have to move back at every remove!
            }
        }
        return staffs;
    }
    public List<Staff> getNonCoordinatorStaffs(Department department){
        List<Staff> staffs = staffRepository.findAllByOrderByFirst_NameAsc();
        List<Coordinator> coordinators = coordinatorRepository.findAll();
        List<Staff> coordinatorStaff = new ArrayList<>();
        for (int i=0; i<coordinators.size(); i++){
            coordinatorStaff.add(coordinators.get(i).getStaff());
        }
        for (int i=0; i<staffs.size(); i++) {
            if(coordinatorStaff.contains(staffs.get(i)) || staffs.get(i).getDepartment().getId() != department.getId()){
                staffs.remove(staffs.get(i));
                i--;        //because when item remove the structure of list is changed. so we have to move back at every remove!
            }
        }
        return staffs;
    }

    @RequestMapping(value = "/{id}/editCoordinator")
    public String editCoordinator(@PathVariable int id, Model model){
        Coordinator coordinator = coordinatorRepository.findById(id);
        model.addAttribute("coordinator", coordinator);
        Department department = coordinator.getDepartment();
        model.addAttribute("department", department);
        List<Staff> staffs = getNonCoordinatorStaffs(department);
        staffs.add(coordinator.getStaff());
        model.addAttribute("staffs", staffs);

        model.addAttribute("isEdit", true);
        return "admin/editCoordinator";
    }

    @PostMapping(value = {"/coordinators/coordinator", "/coordinators/coordinator/{id}"})
    public String addDepartment(@Valid Coordinator coordinator, BindingResult bindingResult, Model model){
        if(coordinator.getStaff().getDepartment().getId() != coordinator.getDepartment().getId()){
            List<Department> departments = getNonCoordinatorDepartments();
            List<Staff> staffs = getNonCoordinatorStaffs();

            model.addAttribute("departments", departments);
            model.addAttribute("staffs", staffs);
            model.addAttribute("coordinator", new Coordinator());
            model.addAttribute("isEdit", false);

            model.addAttribute("staff", coordinator.getStaff());
            model.addAttribute("department", coordinator.getDepartment());

            model.addAttribute("cannotCoordinator", true);

            return "admin/editCoordinator";
        }

        if(coordinator.getId() != 0){
            Coordinator coordinator1 = coordinatorRepository.findById(coordinator.getId());

            Users user = usersRepository.findByStaff(coordinator1.getStaff());
            user.getRoles().remove(roleRepository.findByRole("COORDINATOR"));

            if(user.getRoles().isEmpty()){
                usersRepository.delete(user);
            }
        }

        if(usersRepository.findByStaff(coordinator.getStaff()) == null){
            Users user = new Users(1, coordinator.getStaff().getUserName(), coordinator.getStaff().getPassword(), coordinator.getStaff());
            user.setRole(roleRepository.findByRole("COORDINATOR"));
            user.setCoordinatorId(coordinator.getStaff().getId());
            usersRepository.save(user);
        } else if(usersRepository.findByStaff(coordinator.getStaff()).getStaff() == coordinator.getStaff()){
            Users users = usersRepository.findByStaff(coordinator.getStaff());
            users.setRole(roleRepository.findByRole("COORDINATOR"));
            users.setCoordinatorId(coordinator.getStaff().getId());
        }

        coordinatorRepository.save(coordinator);
        return "redirect:/admin/coordinators";
    }

    @RequestMapping(value = "/{id}/deleteCoordinator")
    public String deleteCoordinator(@PathVariable int id) {

        Coordinator coordinator = coordinatorRepository.findById(id);

        Users user = usersRepository.findByStaff(coordinator.getStaff());
        user.getRoles().remove(roleRepository.findByRole("COORDINATOR"));
        user.setCoordinatorId(0);

        if(user.getRoles().isEmpty()){
            usersRepository.delete(user);
        }

        coordinatorRepository.deleteById(id);
        return "redirect:/admin/coordinators";
    }
}
