package com.example.new1.Repository;

import com.example.new1.Model.Academic.Dean;
import com.example.new1.Model.Academic.Department;
import com.example.new1.Model.Academic.Staff;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface DeanRepository extends JpaRepository<Dean, Integer> {
    @Query("select d from Dean d order by d.college.college_Name")
    List<Dean> findAllByOrOrderByCollegeAsc();

    Dean findById(int id);
    void deleteById(int id);

    List<Dean> findByStaff_Id(int id);
    Dean findByStaff(Staff staff);
}
