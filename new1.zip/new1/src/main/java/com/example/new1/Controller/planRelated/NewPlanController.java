package com.example.new1.Controller.planRelated;

import com.example.new1.Model.Security.Users;
import com.example.new1.Repository.CollegeRepository;
import com.example.new1.Repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import com.example.new1.Model.planRelated.*;
import com.example.new1.Model.reportRelated.*;
import com.example.new1.Repository.general.ScrollRepository;
import com.example.new1.Repository.planRepositories.*;
import com.example.new1.Repository.reportRepositories.*;
import com.example.new1.Repository.DevelopmentRepository;
import com.example.new1.Repository.OneToFiveRepository;
import com.example.new1.Repository.Security.RoleRepository;
import com.example.new1.Repository.Security.UsersRepository;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@Controller
@PreAuthorize("hasAnyRole('ONE_TO_FIVE', 'DEVELOPMENT', 'DEPARTMENT', 'DEAN')")
public class NewPlanController {

    @Autowired
    PlanJpaRepository planJpaRepository;

    @Autowired
    ScrollRepository scrollRepository;

    @Autowired
    UsersRepository usersRepository;

    @Autowired
    OneToFiveRepository oneToFiveRepository;

    @Autowired
    DevelopmentRepository developmentGroupRepository;

    @Autowired
    DepartmentRepository departmentRepository;

    @Autowired
    CollegeRepository collegeRepository;

    @Autowired
    RoleRepository roleRepository;

    List<String> whichOneIsClicked = new ArrayList<>();

    private Users getUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return usersRepository.findUsersByUserName(auth.getName());
    }

    @RequestMapping({"/planServerNewTwo", "/addRow"})
    public String showNewPlan(Plan plan, BindingResult bindingResult, ModelMap modelMap) {
        whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();
        modelMap.put("whichOneIsClicked", whichOneIsClicked);
        modelMap.put("user", getUser());
        return "planServerNewTwo";
    }

    @RequestMapping(value = "/addRow", params = {"newline"})
    public String addRow(Plan plan, BindingResult bindingResult, HttpServletRequest request, ModelMap modelMap) {
        whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();

        switch (request.getParameter("newline")) {
            case "plan1":
                plan.getPlan1s().add(new Plan1());
                whichOneIsClicked.set(0, "theClickedBtn");
                break;
            case "plan2":
                plan.getPlan2s().add(new Plan2());
                whichOneIsClicked.set(1, "theClickedBtn");
                break;
            case "plan3":
                plan.getPlan3s().add(new Plan3());
                whichOneIsClicked.set(2, "theClickedBtn");
                break;
            case "plan4":
                plan.getPlan4s().add(new Plan4());
                whichOneIsClicked.set(3, "theClickedBtn");
                break;
            case "plan5":
                plan.getPlan5s().add(new Plan5());
                whichOneIsClicked.set(4, "theClickedBtn");
                break;
            default:
                break;
        }
        modelMap.put("whichOneIsClicked", whichOneIsClicked);

        modelMap.put("user", getUser());
        return "planServerNewTwo"; /*+"#"+bookmark;*/
    }

    @RequestMapping(value = "/addRow", params = {"dropline"})
    public String removeRow(Plan plan, BindingResult bindingResult, HttpServletRequest request, ModelMap modelMap) {
        whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();
        Integer toBeRemovedId = Integer.valueOf(request.getParameter("dropline").substring(1));

        switch (request.getParameter("dropline").substring(0, 1)) {
            case "1":
                plan.getPlan1s().remove(toBeRemovedId.intValue());
                whichOneIsClicked.set(0, "theClickedBtn");
                break;
            case "2":
                plan.getPlan2s().remove(toBeRemovedId.intValue());
                whichOneIsClicked.set(1, "theClickedBtn");
                break;
            case "3":
                plan.getPlan3s().remove(toBeRemovedId.intValue());
                whichOneIsClicked.set(2, "theClickedBtn");
                break;
            case "4":
                plan.getPlan4s().remove(toBeRemovedId.intValue());
                whichOneIsClicked.set(3, "theClickedBtn");
                break;
            case "5":
                plan.getPlan5s().remove(toBeRemovedId.intValue());
                whichOneIsClicked.set(4, "theClickedBtn");
                break;
            default:
                break;
        }
        modelMap.put("whichOneIsClicked", whichOneIsClicked);

        modelMap.put("user", getUser());
        return "planServerNewTwo";
    }


    @RequestMapping(value = "/addRow", params = {"saveAllData"})
    public String saveAllPlans(@Valid Plan plan, BindingResult bindingResult, ModelMap modelMap, HttpServletRequest request) {

        Integer receiverId = Integer.valueOf(request.getParameter("saveAllData"));

        if (bindingResult.hasErrors()) {
            whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();
            modelMap.put("whichOneIsClicked", whichOneIsClicked);

            modelMap.put("user", getUser());
            return "planServerNewTwo";
        } else if (plan.getPlan1s().isEmpty() && plan.getPlan2s().isEmpty() && plan.getPlan3s().isEmpty() && plan.getPlan4s().isEmpty() && plan.getPlan5s().isEmpty()) {
            whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();
            modelMap.put("whichOneIsClicked", whichOneIsClicked);

            modelMap.put("user", getUser());
            modelMap.put("allEmpty", true);
            return "planServerNewTwo";
        }

        planJpaRepository.save(plan);

        incrementNewlyCreatedPlans(receiverId);

        return "redirect:/plansList";
    }

    public void incrementNewlyCreatedPlans(Integer receiverId) {
        if (((getUser().getOneToFiveId() != null) && (getUser().getOneToFiveId().getDevelopmentGroup() != null))) {     //if the sender is 125 leader AND Only INVOLVED(not leading) in some development group and sending to the development group; Or works also for a development leader also, who is sending to the development that he is in or he leads;
            if (getUser().getOneToFiveId().getDevelopmentGroup().getId() == receiverId) {
                getUser().getOneToFiveId().getDevelopmentGroup().incrementNewPlans();
                developmentGroupRepository.save(getUser().getOneToFiveId().getDevelopmentGroup());
            }
        }
        if (getUser().getDevelopmentId() != null) {     //if the sender is a development leader and he is sending to the department that his development is in;
            if (getUser().getDevelopmentId().getDepartment().getId() == receiverId) {
                getUser().getDevelopmentId().getDepartment().incrementNewPlans();
                departmentRepository.save(getUser().getDevelopmentId().getDepartment());
            }
        }
        if (getUser().getHeadDepartmentId() != null) {     //if the sender is a department head and he is sending to the college his department is in;
            if (getUser().getHeadDepartmentId().getCollege().getId() == receiverId) {
                getUser().getHeadDepartmentId().getCollege().incrementNewPlans();
                collegeRepository.save(getUser().getHeadDepartmentId().getCollege());
            }
        }
    }
}
