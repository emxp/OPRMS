package com.example.new1.Repository.reportRepositories;

import com.example.new1.Model.reportRelated.Report3;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

@Component
public interface Report3JpaRepository extends JpaRepository<Report3, Integer> {
}
