package com.example.new1.Model.Administration;

import com.example.new1.Model.Academic.College;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.*;
import javax.validation.constraints.Pattern;

@Entity
public class Directorate {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    @NotEmpty(message = "You must fill the name field")
    @Length(max = 100)
    @Pattern(regexp = "[A-z /s]*", message = "You must fill the name field by letter")
    private String dir_Name;
    @ManyToOne
    @JoinColumn(name = "office_id", referencedColumnName = "id")
    private VPOffice vpOffice;

    public Directorate() {
    }

    public Directorate(String dir_Name, VPOffice vpOffice) {
        this.dir_Name = dir_Name;
        this.vpOffice = vpOffice;
    }

    public int getId() {
        return id;
    }

    public String getDir_Name() {
        return dir_Name;
    }

    public void setDir_Name(String dir_Name) {
        this.dir_Name = dir_Name;
    }

    public VPOffice getVpOffice() {
        return vpOffice;
    }

    public void setVpOffice(VPOffice vpOffice) {
        this.vpOffice = vpOffice;
    }
}
