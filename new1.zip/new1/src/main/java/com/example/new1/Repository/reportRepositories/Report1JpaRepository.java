package com.example.new1.Repository.reportRepositories;

import com.example.new1.Model.reportRelated.Report1;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

@Component
public interface Report1JpaRepository extends JpaRepository<Report1, Integer> {
}
