package com.example.new1.Model.reportRelated;

import com.example.new1.Model.planRelated.Plan4;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@Entity
public class Report4 {
    @Id
    private int id;

    @Column(name = "report_id", insertable = false, updatable = false)
    private int reportId;

    @Min(value = 0, message = "ከዜሮ ማነስ የለበትም!")
    @Max(value = 100, message = "ከመቶ መብለጥ የለበትም!")
    @NotNull(message = "አፈፃፀም ያስገቡ!")
    private Integer percentage;

    @Column(columnDefinition = "TEXT")
    private String ifNotWhy;

    @OneToOne()
    @JoinColumn(name = "id", referencedColumnName = "id")
    private Plan4 plan4;

    public Report4() {
    }

    public Report4(int id, Plan4 plan4) {
        this.id = id;
        this.plan4 = plan4;
    }

    public int getId() {
        return id;
    }

    public int getReportId() {
        return reportId;
    }

    public String getIfNotWhy() {
        return ifNotWhy;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setReportId(int reportId) {
        this.reportId = reportId;
    }

    public void setIfNotWhy(String ifNotWhy) {
        this.ifNotWhy = ifNotWhy;
    }

    public Plan4 getPlan4() {
        return plan4;
    }

    public void setPlan4(Plan4 plan4) {
        this.plan4 = plan4;
    }

    public Integer getPercentage() {
        return percentage;
    }

    public void setPercentage(Integer percentage) {
        this.percentage = percentage;
    }
}
