package com.example.new1.Repository.planRepositories;

import com.example.new1.Model.planRelated.Plan;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface PlanPagingRepository extends PagingAndSortingRepository<Plan, Integer> {
    Page<Plan> findBySenderGroupId(int senderGroupId, Pageable pageable);
    Page<Plan> findByReceiverGroupId(int receiverGroupId, Pageable pageable);
}

