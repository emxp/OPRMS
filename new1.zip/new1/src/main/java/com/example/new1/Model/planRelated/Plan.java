package com.example.new1.Model.planRelated;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import javax.validation.Valid;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Component
@Entity
@Table(name = "plan")
public class Plan {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "plan_id")
    private int id;

    @Column(name = "new_plan")
    private boolean newPlan;

    @Column(name = "sender_group_id")
    private int senderGroupId;

    @NotNull(message = "ቀኑን ያስገቡ!")
    @Future(message = "ቀኑ መቅደም አለበት!")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate date = LocalDate.of(2018, 5, 3);

    @Column(name = "receiver_group_id")
    private int receiverGroupId;

    @Valid
    @NotNull(message = "ioiuuuuuuuuuuuuuuuuuu")
//    @NotEmpty(message = "በመማር ማስተማር ዙሪያ ቢያንስ አንድ እቅድ ማስገባት አለብዎት!")
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "plan_id", referencedColumnName = "plan_id")
    private List<Plan1> plan1s = new ArrayList<>();

    @Valid
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "plan_id", referencedColumnName = "plan_id")
    private List<Plan2> plan2s = new ArrayList<>();

    @Valid
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "plan_id", referencedColumnName = "plan_id")
    private List<Plan3> plan3s = new ArrayList<>();

    @Valid
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "plan_id", referencedColumnName = "plan_id")
    private List<Plan4> plan4s = new ArrayList<>();

    @Valid
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "plan_id", referencedColumnName = "plan_id")
    private List<Plan5> plan5s = new ArrayList<>();

    public List<Plan2> getPlan2s() {
        return plan2s;
    }

    public void setPlan2s(List<Plan2> plan2s) {
        this.plan2s = plan2s;
    }

    public List<Plan3> getPlan3s() {
        return plan3s;
    }

    public void setPlan3s(List<Plan3> plan3s) {
        this.plan3s = plan3s;
    }

    public List<Plan4> getPlan4s() {
        return plan4s;
    }

    public void setPlan4s(List<Plan4> plan4s) {
        this.plan4s = plan4s;
    }

    public List<Plan5> getPlan5s() {
        return plan5s;
    }

    public void setPlan5s(List<Plan5> plan5s) {
        this.plan5s = plan5s;
    }

    public List<Plan1> getPlan1s() {
        return plan1s;
    }

    public void setPlan1s(List<Plan1> plan1s) {
        this.plan1s = plan1s;
    }

    public Plan(int senderGroupId, LocalDate date, int receiverGroupId) {
        this.senderGroupId = senderGroupId;
        this.date = date;
        this.receiverGroupId = receiverGroupId;
    }

    public Plan() {
        newPlan = true;
    }

    public int getId() {
        return id;
    }


    public LocalDate getDate() {
        return date;
    }


    public void setId(int id) {
        this.id = id;
    }


    public void setDate(LocalDate date) {
        this.date = date;
    }

    public int getSenderGroupId() {
        return senderGroupId;
    }

    public void setSenderGroupId(int senderGroupId) {
        this.senderGroupId = senderGroupId;
    }

    public int getReceiverGroupId() {
        return receiverGroupId;
    }

    public void setReceiverGroupId(int receiverGroupId) {
        this.receiverGroupId = receiverGroupId;
    }

    public boolean isNewPlan() {
        return newPlan;
    }

    public void setNewPlan(boolean newPlan) {
        this.newPlan = newPlan;
    }
}
