package com.example.new1.Controller.staff;

import com.example.new1.Model.Academic.OneToFiveGroup;
import com.example.new1.Model.Academic.Staff;
import com.example.new1.Model.Security.Users;
import com.example.new1.Repository.*;
import com.example.new1.Repository.Security.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping(value = "/staff")
public class profileController {

    @Autowired
    private UsersRepository usersRepository;

    @Autowired
    private StaffRepository staffRepository;

    @Autowired
    private OneToFiveRepository oneToFiveRepository;

    @Autowired
    private DevelopmentRepository developmentRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    @Autowired
    private CollegeRepository collegeRepository;

    public Users getUser(){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return usersRepository.findUsersByUserName(auth.getName());
    }

    @RequestMapping(value = "/profile")
    public String showProfile(Model model){
        Users users = getUser();

        if(users.isInOneToFive()){
            model.addAttribute("oneToFive", oneToFiveRepository.findById(users.getOneToFiveId().getId()));
        }

        if(users.isInDevelopment()){
            model.addAttribute("development", developmentRepository.findById(users.getDevelopmentId().getId()));
        }

        if(users.isInCoordinator() || users.isDepartmentHead()){
            model.addAttribute("department", departmentRepository.findById(users.getStaff().getDepartment().getId()));
        }

        if(users.isDean()){
            model.addAttribute("college", collegeRepository.findById(users.getDeanId().getId()));
        }

        model.addAttribute("user", getUser());
        return "staff/profile";
    }

    @RequestMapping(value = "/editPassword")
    public String editPassword(Model model){

        model.addAttribute("user", getUser());
        return "staff/editPassword";
    }

    @RequestMapping(value ="/editPassword", params = "change")
    public String newPassword(@RequestParam("current") String current,
                              @RequestParam("new") String newPassword,
                              @RequestParam("confirm") String confirm, Model model){

        Users users = getUser();
        if(users.getPassword().equals(current)){
            if(newPassword.equals(confirm)){
                users.setPassword(newPassword);
                users.getStaff().setPassword(newPassword);
                usersRepository.save(users);
                return "redirect:/staff/profile";
            }else{
                model.addAttribute("notSame", true);
                model.addAttribute("user", getUser());
                return "staff/editPassword";
            }
        }else{
            model.addAttribute("notSuccess", true);
            model.addAttribute("user", getUser());
            return "staff/editPassword";
        }
    }
}
