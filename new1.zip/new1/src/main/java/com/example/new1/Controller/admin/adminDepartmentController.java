package com.example.new1.Controller.admin;

import com.example.new1.Model.Academic.College;
import com.example.new1.Model.Academic.Department;
import com.example.new1.Repository.CollegeRepository;
import com.example.new1.Repository.DepartmentRepository;
import com.example.new1.Repository.StaffRepository;
import com.sun.org.apache.xpath.internal.operations.Mod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;
import java.util.List;

@Controller
@RequestMapping(value = "/admin")
@PreAuthorize("hasAnyRole('ADMIN')")
public class adminDepartmentController {

    @Autowired
    private DepartmentRepository departmentRepository;
    @Autowired
    private CollegeRepository collegeRepository;
    @Autowired
    private StaffRepository staffRepository;

    @RequestMapping("/departments")
    public String listDepartments(ModelMap modelMap){
        List<Department> allDepartment = departmentRepository.findAllByOrderByDep_NameAsc();
        modelMap.put("departments", allDepartment);
        return "admin/adminDepartment";
    }

    @PostMapping(value = {"/departments/department", "/departments/department/{id}"})
    public String addDepartment(@Valid Department department, BindingResult bindingResult, Model model){
        if (bindingResult.hasErrors()) {
            if(department.getId() == 0){
                List<College> allCollege = collegeRepository.findAll();
                model.addAttribute("colleges", allCollege);
                model.addAttribute("isEdit", false);
            }else{
                List<College> allCollege = collegeRepository.findAll();
                model.addAttribute("colleges", allCollege);
                model.addAttribute("isEdit", true);
            }
            return "admin/editDepartment";
        }
        departmentRepository.save(department);
        return "redirect:/admin/departments";
    }

    @RequestMapping(value = "/{id}/editDepartment")
    public String editDepartment(@PathVariable int id, Model model){
        Department department = departmentRepository.findById(id);
        model.addAttribute("department", department);
        List<College> allCollege = collegeRepository.findAll();
        model.addAttribute("colleges", allCollege);
        model.addAttribute("isEdit", true);
        return "admin/editDepartment";
    }
    @RequestMapping(value = "/addDepartment")
    public String addDepartment(Model model){
        List<College> allCollege = collegeRepository.findAll();
        model.addAttribute("colleges", allCollege);
        model.addAttribute("department", new Department());
        model.addAttribute("isEdit", false);
        return "admin/editDepartment";
    }

    @RequestMapping(value = "/{id}/deleteDepartment")
    public String deleteDepartment(@PathVariable int id, Model model){
        if(staffRepository.findByDepartment_Id(id).isEmpty()){
            departmentRepository.deleteById(id);
            return "redirect:/admin/departments";
        }else {
            List<Department> allDepartment = departmentRepository.findAllByOrderByDep_NameAsc();
            model.addAttribute("departments", allDepartment);
            Department department = departmentRepository.findById(id);
            model.addAttribute("deletedDepartment", department);
            model.addAttribute("canNotDelete", true);
            return "admin/adminDepartment";
        }
    }
}
