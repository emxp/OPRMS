package com.example.new1.Repository.reportRepositories;

import com.example.new1.Model.reportRelated.Report2;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

@Component
public interface Report2JpaRepository extends JpaRepository<Report2, Integer> {
}
