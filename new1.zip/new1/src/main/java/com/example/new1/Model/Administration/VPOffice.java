package com.example.new1.Model.Administration;

import org.hibernate.validator.constraints.Length;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@Entity
public class VPOffice {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @NotEmpty(message = "You must fill the name field")
    @Length(max = 100)
    @Pattern(regexp = "[A-z /s]*", message = "You must fill the name field by letter")
    private String vpOffice;

    public VPOffice() {
    }

    public VPOffice(String vpOffice) {
        this.vpOffice = vpOffice;
    }

    public int getId() {
        return id;
    }

    public String getVpOffice() {
        return vpOffice;
    }

    public void setVpOffice(String vpOffice) {
        this.vpOffice = vpOffice;
    }
}
