package com.example.new1.Repository;

import com.example.new1.Model.Academic.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface DepartmentRepository extends JpaRepository<Department, Integer> {
    Department findById(int id);
    List<Department> findByCollege_Id(int id);
    @Query("select d from Department d order by d.dep_Name")
    List<Department> findAllByOrderByDep_NameAsc();
    void deleteById(int id);
}
