package com.example.new1.Controller.staff;

import com.example.new1.Model.Academic.Department;
import com.example.new1.Model.Academic.DevelopmentGroup;
import com.example.new1.Model.Academic.OneToFiveGroup;
import com.example.new1.Model.Security.Users;
import com.example.new1.Repository.DepartmentRepository;
import com.example.new1.Repository.DevelopmentRepository;
import com.example.new1.Repository.OneToFiveRepository;
import com.example.new1.Repository.Security.UsersRepository;
import com.example.new1.Repository.StaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping(value = "/staff")
@PreAuthorize("hasAnyRole('ONE_TO_FIVE', 'DEVELOPMENT', 'COORDINATOR', 'DEPARTMENT', 'DEAN')")
public class coordinationController {

    @Autowired
    private StaffRepository staffRepository;

    @Autowired
    private OneToFiveRepository oneToFiveRepository;

    @Autowired
    private DevelopmentRepository developmentRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    @Autowired
    private UsersRepository usersRepository;

    private Users getUsers() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return usersRepository.findUsersByUserName(auth.getName());
    }

    @RequestMapping(value = "/coordination")
    public String showCoordination(Model model){
        Users user = getUsers();

        List<OneToFiveGroup> oneToFiveGroups = new ArrayList<>();
        List<DevelopmentGroup> developmentGroups = new ArrayList<>();

        if(user.isDean()){

            List<Department> departments = departmentRepository.findByCollege_Id(user.getStaff().getDepartment().getCollege().getId());

            for (int i=0; i<departments.size(); i++){
                oneToFiveGroups.addAll(oneToFiveRepository.findByDepartment_Id(departments.get(i).getId()));
                developmentGroups.addAll(developmentRepository.findByDepartment_Id(departments.get(i).getId()));
            }

            model.addAttribute("oneToFiveGroups", oneToFiveGroups);
            model.addAttribute("developmentGroups", developmentGroups);

            model.addAttribute("empty1to5College", checkEmpty1to5(oneToFiveGroups));
            model.addAttribute("emptyDevCollege", checkEmptyDev(developmentGroups));

        } else if(user.isDepartmentHead()){
            oneToFiveGroups.addAll(oneToFiveRepository.findByDepartment_Id(user.getStaff().getDepartment().getId()));
            developmentGroups.addAll(developmentRepository.findByDepartment_Id(user.getStaff().getDepartment().getId()));

            model.addAttribute("oneToFiveGroups", oneToFiveGroups);
            model.addAttribute("developmentGroups", developmentGroups);

            model.addAttribute("empty1to5", checkEmpty1to5(oneToFiveGroups));
            model.addAttribute("emptyDev", checkEmptyDev(developmentGroups));

        } else if(user.isInDevelopment()){
            model.addAttribute("oneToFiveGroups", oneToFiveRepository.findByDevelopmentGroupId(user.getDevelopmentId().getId()));
            model.addAttribute("developmentGroups", developmentRepository.findById(user.getDevelopmentId().getId()));
        } else if (user.isInOneToFive()){

            OneToFiveGroup oneToFiveGroup = oneToFiveRepository.findById(user.getOneToFiveId().getId());
            model.addAttribute("oneToFiveGroups", oneToFiveGroup);

            if(oneToFiveGroup.getDevelopmentGroup() != null){
                model.addAttribute("developmentGroups", developmentRepository.findById(oneToFiveGroup.getDevelopmentGroup().getId()));
            }else{
                model.addAttribute("developmentGroups", null);
                model.addAttribute("noDev", true);
            }

        }


        model.addAttribute("user", user);
        return "staff/staffCoordination";
    }

    public boolean checkEmpty1to5(List<OneToFiveGroup> oneToFiveGroups){
        return oneToFiveGroups.isEmpty();
    }

    public boolean checkEmptyDev(List<DevelopmentGroup> developmentGroups){
        return developmentGroups.isEmpty();
    }


}
