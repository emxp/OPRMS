package com.example.new1.Repository.reportRepositories;

import com.example.new1.Model.reportRelated.Report5;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

@Component
public interface Report5JpaRepository extends JpaRepository<Report5, Integer> {
}
