package com.example.new1.Repository.Security;

import com.example.new1.Model.Academic.Staff;
import com.example.new1.Model.Security.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

public interface UsersRepository extends JpaRepository<Users, Integer> {
    Optional<Users> findByUserName(String username);

    Users findUsersByUserName(String name);
    Users findById(int id);
    Users findByStaff(Staff staff);
}
