package com.example.new1.Repository;

import com.example.new1.Model.Academic.Department;
import com.example.new1.Model.Academic.Staff;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface StaffRepository extends JpaRepository<Staff, Integer>{
    Staff findById(int id);
    List<Staff> findByDepartment_Id(int id);
    void deleteById(int id);

    @Query("select s from Staff s order by s.first_Name")
    List<Staff> findAllByOrderByFirst_NameAsc();
}
