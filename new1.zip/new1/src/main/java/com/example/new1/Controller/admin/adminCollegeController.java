package com.example.new1.Controller.admin;

import com.example.new1.Model.Academic.College;
import com.example.new1.Repository.CollegeRepository;
import com.example.new1.Repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;
import java.util.List;

@Controller
@RequestMapping(value = "/admin")
@PreAuthorize("hasAnyRole('ADMIN')")
public class adminCollegeController {

    @Autowired
    private CollegeRepository collegeRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    @RequestMapping("/colleges")
    public String listColleges(ModelMap modelMap){
        List<College> allCollege = collegeRepository.findAllByOrderByCollege_NameAsc();
        modelMap.put("colleges", allCollege);
        return "admin/adminCollege";
    }

    @PostMapping(value = {"/colleges/college", "/colleges/college/{id}"})
    public String addCollege(@Valid College college, BindingResult bindingResult, Model model){
        if (bindingResult.hasErrors()) {
            if(college.getId() == 0){
                model.addAttribute("isEdit", false);
            }else{
                model.addAttribute("isEdit", true);
            }
            return "admin/editCollege";
        }
        collegeRepository.save(college);
        return "redirect:/admin/colleges";
    }

    @RequestMapping(value = "/{id}/editCollege", params = "edit=true")
    public String editCollege(ModelMap modelMap, @PathVariable int id){
        College college = collegeRepository.findById(id);
        modelMap.put("college", college);
        modelMap.put("isEdit", true);
        return "admin/editCollege";
    }
    @RequestMapping(value = "/addCollege")
    public String addCollege(ModelMap modelMap){
        modelMap.put("college", new College());
        modelMap.put("isEdit", false);
        return "admin/editCollege";
    }

    @RequestMapping(value = "/{id}/deleteCollege")
    public String deleteCollege(@PathVariable int id, Model model){
        if(departmentRepository.findByCollege_Id(id).isEmpty()){
            collegeRepository.deleteById(id);
            return "redirect:/admin/colleges";
        }else {
            List<College> allCollege = collegeRepository.findAllByOrderByCollege_NameAsc();
            College college = collegeRepository.findById(id);
            model.addAttribute("colleges", allCollege);
            model.addAttribute("deletedCollege", college);
            model.addAttribute("canNotDelete", true);
            return "admin/adminCollege";
        }
    }
}
