package com.example.new1.Controller.reportRelated;

import com.example.new1.Model.Academic.Dean;
import com.example.new1.Repository.*;
import com.example.new1.Repository.reportRepositories.ReportPagingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import com.example.new1.Model.Security.Users;
import com.example.new1.Model.reportRelated.*;
import com.example.new1.Repository.Security.UsersRepository;
import com.example.new1.Repository.general.ScrollRepository;
import com.example.new1.Repository.reportRepositories.ReportJpaRepository;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

@Controller
@PreAuthorize("hasAnyRole('ONE_TO_FIVE' , 'COORDINATOR' , 'DEVELOPMENT', 'DEPARTMENT', 'DEAN')")
public class reportsListController {

    @Autowired
    ReportJpaRepository reportJpaRepository;

    @Autowired
    ScrollRepository scrollRepository;

    @Autowired
    UsersRepository usersRepository;

    @Autowired
    OneToFiveRepository oneToFiveRepository;

    @Autowired
    DevelopmentRepository developmentGroupRepository;

    @Autowired
    DepartmentRepository departmentRepository;

    @Autowired
    CollegeRepository collegeRepository;

    @Autowired
    DeanRepository deanRepository;

    @Autowired
    ReportPagingRepository reportPagingRepository;

    List<String> whichOneIsClicked = new ArrayList<>();

    private Users getUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return usersRepository.findUsersByUserName(auth.getName());
    }

    @RequestMapping("/reportsList")
    public String showReportList(ModelMap modelMap, @RequestParam(defaultValue = "1") int pageOneToFiveSent, @RequestParam(defaultValue = "1") int pageDevSent, @RequestParam(defaultValue = "1") int pageDevReceived, @RequestParam(defaultValue = "1") int pageDepHeadSent, @RequestParam(defaultValue = "1") int pageDepHeadReceived, @RequestParam(defaultValue = "1") int pageDeanSent, @RequestParam(defaultValue = "1") int pageDeanReceived) {
        whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();
        Users user = getUser();

        if (user.isDean()) {
            Dean dean = deanRepository.findByStaff(user.getStaff());
            modelMap.put("allSentReportsByDean", reportPagingRepository.findBySenderGroupId(user.getDeanId().getId(), PageRequest.of(pageDeanSent - 1, 6, Sort.Direction.DESC, "id")));
            modelMap.put("allReceivedReportsByDean", reportPagingRepository.findByReceiverGroupId(user.getDeanId().getId(), PageRequest.of(pageDeanReceived - 1, 6, Sort.Direction.DESC, "id")));
            modelMap.put("college", dean.getCollege());
        }else if (user.isDepartmentHead()) {
            modelMap.put("allSentReportsByDepartment", reportPagingRepository.findBySenderGroupId(user.getStaff().getDepartment().getId(), PageRequest.of(pageDepHeadSent - 1, 6, Sort.Direction.DESC, "id")));
            modelMap.put("allReceivedReportsByDepartment", reportPagingRepository.findByReceiverGroupId(user.getStaff().getDepartment().getId(), PageRequest.of(pageDepHeadReceived - 1, 6, Sort.Direction.DESC, "id")));
            modelMap.put("department", user.getStaff().getDepartment());
        }
        if (user.isInDevelopment()) {
            modelMap.put("allSentReportsByOneToFive", reportPagingRepository.findBySenderGroupId(user.getOneToFiveId().getId(), PageRequest.of(pageOneToFiveSent - 1, 6, Sort.Direction.DESC, "id")));
            modelMap.put("allSentReportsByDevelopment", reportPagingRepository.findBySenderGroupId(user.getDevelopmentId().getId(), PageRequest.of(pageDevSent - 1, 6, Sort.Direction.DESC, "id")));
            modelMap.put("allReceivedReportsByDevelopment", reportPagingRepository.findByReceiverGroupId(user.getDevelopmentId().getId(), PageRequest.of(pageDevReceived - 1, 6, Sort.Direction.DESC, "id")));
            modelMap.put("oneToFive", oneToFiveRepository.getOne(user.getOneToFiveId().getId()));
            modelMap.put("development", developmentGroupRepository.getOne(user.getDevelopmentId().getId()));
        } else if (user.isInOneToFive()) {
            modelMap.put("allSentReportsByOneToFive", reportPagingRepository.findBySenderGroupId(user.getOneToFiveId().getId(), PageRequest.of(pageOneToFiveSent - 1, 6, Sort.Direction.DESC, "id")));
            modelMap.put("oneToFive", oneToFiveRepository.getOne(user.getOneToFiveId().getId()));
        }

        whichOneIsClicked = scrollRepository.setTheClickedValue(pageOneToFiveSent, pageDevSent, pageDevReceived, pageDepHeadSent, pageDepHeadReceived, pageDeanSent, pageDeanReceived);

        modelMap.put("user", getUser());
        modelMap.put("currentPageOneToFiveSent", pageOneToFiveSent);
        modelMap.put("currentPageDevSent", pageDevSent);
        modelMap.put("currentPageDevReceived", pageDevReceived);
        modelMap.put("currentPageDepHeadSent", pageDepHeadSent);
        modelMap.put("currentPageDepHeadReceived", pageDepHeadReceived);
        modelMap.put("currentPageDeanSent", pageDeanSent);
        modelMap.put("currentPageDeanReceived", pageDeanReceived);

        modelMap.put("whichOneIsClicked", whichOneIsClicked);

        return "reportsList";
    }

    @RequestMapping(value = "/reportsList", params = {"kifet"})
    public String showASingleReport(ModelMap modelMap, HttpServletRequest request) {

        Integer newRep = Integer.parseInt(request.getParameter("kifet").substring(0, 1));
        Integer id = Integer.parseInt(request.getParameter("kifet").substring(1));

        Report report = reportJpaRepository.getOne(id.intValue());

        if (newRep == 1)
            modelMap.put("newRep", true);

        if (report.isNewReport())
            decrementViewedReports(report);

        modelMap.put("report", report);

        modelMap.put("user", getUser());
        return "reportServer";
    }

    @RequestMapping(value = "/reportsList", params = {"atifa"})
    public String deleteASingleReport(HttpServletRequest request) {

        Integer id = Integer.parseInt(request.getParameter("atifa"));
        Report report = reportJpaRepository.getOne(id);

        if (report.isNewReport())
            decrementViewedReports(report);

        reportJpaRepository.deleteById(id.intValue());

        return "redirect:/reportsList";
    }
//
    @RequestMapping(value = "/reportsList", params = {"astekakil"})
    public String editASingleReport(Report report, BindingResult bindingResult, HttpServletRequest request, ModelMap modelMap) {

        whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();
        Integer id = Integer.parseInt(request.getParameter("astekakil"));

        report = reportJpaRepository.getOne(id.intValue());

        modelMap.put("report", report);
        modelMap.put("whichOneIsClicked", whichOneIsClicked);

        modelMap.put("user", getUser());
        return "editReport";
    }

    public void decrementViewedReports(Report report) {
        if (report.isNewReport()) {         //When a sender clicks the report he get into this if clause, but can not do any thing;
            if (getUser().isInDevelopment() && (getUser().getDevelopmentId().getId() == report.getReceiverGroupId())) {          //if the user(receiver) is a development leader;
                if (getUser().getDevelopmentId().getNewReports() > 0) {
                    getUser().getDevelopmentId().decrementNewReports();
                    developmentGroupRepository.save(getUser().getDevelopmentId());
                    report.setNewReport(false);
                    reportJpaRepository.save(report);
                }
            }
            if (getUser().isDepartmentHead() && (getUser().getHeadDepartmentId().getId() == report.getReceiverGroupId())) {     //if the user(receiver) is department head;
                if (getUser().getHeadDepartmentId().getNewReports() > 0) {
                    getUser().getHeadDepartmentId().decrementNewReports();
                    departmentRepository.save(getUser().getHeadDepartmentId());
                    report.setNewReport(false);
                    reportJpaRepository.save(report);
                }
            }
            if (getUser().isDean() && (getUser().getDeanId().getId() == report.getReceiverGroupId())) {
                if (getUser().getDeanId().getNewReports() > 0) {
                    getUser().getDeanId().decrementNewReports();
                    collegeRepository.save(getUser().getDeanId());
                    report.setNewReport(false);
                    reportJpaRepository.save(report);
                }
            }
        }
    }

}
