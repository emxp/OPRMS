package com.example.new1.Model.reportRelated;

import com.example.new1.Model.planRelated.Plan1;

import javax.persistence.*;
import javax.validation.constraints.*;

@Entity
public class Report1 {
    @Id
    private int id;

    @Column(name = "report_id", insertable = false, updatable = false)
    private int reportId;

    @Min(value = 0, message = "ከዜሮ ማነስ የለበትም!")
    @Max(value = 100, message = "ከመቶ መብለጥ የለበትም!")
    @NotNull(message = "አፈፃፀም ያስገቡ!")
    private Integer percentage;

    @Column(columnDefinition = "TEXT")
    private String ifNotWhy;

    @OneToOne()
    @JoinColumn(name = "id", referencedColumnName = "id")
    private Plan1 plan1;

    public Report1() {
    }

    public Report1(int id, Plan1 plan1) {
        this.id = id;
        this.plan1 = plan1;
    }

    public int getId() {
        return id;
    }

    public int getReportId() {
        return reportId;
    }

    public String getIfNotWhy() {
        return ifNotWhy;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setReportId(int reportId) {
        this.reportId = reportId;
    }

    public void setIfNotWhy(String ifNotWhy) {
        this.ifNotWhy = ifNotWhy;
    }

    public Plan1 getPlan1() {
        return plan1;
    }

    public void setPlan1(Plan1 plan1) {
        this.plan1 = plan1;
    }

    public Integer getPercentage() {
        return percentage;
    }

    public void setPercentage(Integer percentage) {
        this.percentage = percentage;
    }
}
