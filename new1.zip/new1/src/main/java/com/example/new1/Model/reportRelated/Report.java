package com.example.new1.Model.reportRelated;

import com.example.new1.Model.planRelated.Plan;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.Valid;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "report", catalog = "test")
public class Report {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "report_id")
    private int id;

    @Column(name = "sender_group_id")
    private int senderGroupId;

    @NotNull(message = "ቀኑን ያስገቡ!")
    @Future(message = "ቀኑ መቅደም አለበት!")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate date = LocalDate.of(2018, 5, 3);

    @Column(name = "receiver_group_id")
    private int receiverGroupId;

    @Column(name = "new_plan")
    private boolean newReport;

    @Column(name = "plan_id")
    private int planId;

    @Valid
    @OneToOne()
    @JoinColumn(name = "plan_id", referencedColumnName = "plan_id", insertable = false, updatable = false)
    private Plan plan;

    @Valid
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "report_id", referencedColumnName = "report_id")
    private List<Report1> report1s = new ArrayList<>();

    @Valid
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "report_id", referencedColumnName = "report_id")
    private List<Report2> report2s = new ArrayList<>();

    @Valid
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "report_id", referencedColumnName = "report_id")
    private List<Report3> report3s = new ArrayList<>();

    @Valid
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "report_id", referencedColumnName = "report_id")
    private List<Report4> report4s = new ArrayList<>();

    @Valid
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "report_id", referencedColumnName = "report_id")
    private List<Report5> report5s = new ArrayList<>();

    @Valid
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "report_id", referencedColumnName = "report_id")
    private List<OccurredProblem> occurredProblems = new ArrayList<>();

    @Valid
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "report_id", referencedColumnName = "report_id")
    private List<UnsolvedProblem> unsolvedProblems = new ArrayList<>();

    public Report(int senderGroupId, LocalDate date, int receiverGroupId, int planId, Plan plan) {
        this.senderGroupId = senderGroupId;
        this.date = date;
        this.receiverGroupId = receiverGroupId;
        this.planId = planId;
        this.plan = plan;
    }

    public Report() {
        newReport = true;
    }

    public int getId() {
        return id;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public List<Report1> getReport1s() {
        return report1s;
    }

    public void setReport1s(List<Report1> report1s) {
        this.report1s = report1s;
    }

    public int getPlanId() {
        return planId;
    }

    public void setPlanId(int planId) {
        this.planId = planId;
    }

    public Plan getPlan() {
        return plan;
    }

    public void setPlan(Plan plan) {
        this.plan = plan;
    }

    public List<OccurredProblem> getOccurredProblems() {
        return occurredProblems;
    }

    public void setOccurredProblems(List<OccurredProblem> occurredProblems) {
        this.occurredProblems = occurredProblems;
    }

    public List<UnsolvedProblem> getUnsolvedProblems() {
        return unsolvedProblems;
    }

    public void setUnsolvedProblems(List<UnsolvedProblem> unsolvedProblems) {
        this.unsolvedProblems = unsolvedProblems;
    }

    public List<Report2> getReport2s() {
        return report2s;
    }

    public void setReport2s(List<Report2> report2s) {
        this.report2s = report2s;
    }

    public List<Report3> getReport3s() {
        return report3s;
    }

    public void setReport3s(List<Report3> report3s) {
        this.report3s = report3s;
    }

    public List<Report4> getReport4s() {
        return report4s;
    }

    public void setReport4s(List<Report4> report4s) {
        this.report4s = report4s;
    }

    public List<Report5> getReport5s() {
        return report5s;
    }

    public void setReport5s(List<Report5> report5s) {
        this.report5s = report5s;
    }

    public int getSenderGroupId() {
        return senderGroupId;
    }

    public void setSenderGroupId(int senderGroupId) {
        this.senderGroupId = senderGroupId;
    }

    public int getReceiverGroupId() {
        return receiverGroupId;
    }

    public void setReceiverGroupId(int receiverGroupId) {
        this.receiverGroupId = receiverGroupId;
    }

    public boolean isNewReport() {
        return newReport;
    }

    public void setNewReport(boolean newReport) {
        this.newReport = newReport;
    }
}
