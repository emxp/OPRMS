package com.example.new1.Repository.reportRepositories;

import com.example.new1.Model.reportRelated.Report;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface ReportPagingRepository extends PagingAndSortingRepository<Report, Integer> {
    Page<Report> findBySenderGroupId(int senderGroupId, Pageable pageable);
    Page<Report> findByReceiverGroupId(int receiverGroupId, Pageable pageable);
}
