package com.example.new1.Controller.reportRelated;

import com.example.new1.Model.Security.Users;
import com.example.new1.Repository.Security.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import com.example.new1.Model.reportRelated.*;
import com.example.new1.Repository.reportRepositories.ReportJpaRepository;

import javax.persistence.ManyToOne;
import java.util.List;

@Controller
@PreAuthorize("hasAnyRole('ONE_TO_FIVE', 'DEVELOPMENT', 'DEPARTMENT', 'DEAN')")
public class ReportViewerController {

    @Autowired
    ReportJpaRepository reportJpaRepository;

    @Autowired
    UsersRepository usersRepository;

    private Users getUsers() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return usersRepository.findUsersByUserName(auth.getName());
    }

    @RequestMapping("/reportServer/{id}")
    public String showReports(ModelMap modelMap, @PathVariable int id) {

        Report report = reportJpaRepository.findByPlanId(id);

        modelMap.put("report", report);
        modelMap.put("user", getUsers());
        return "reportServer";
    }

    @RequestMapping("/reportServer")
    public String showAReport(ModelMap modelMap) {

        modelMap.put("user", getUsers());
        return "reportServer";
    }

}
