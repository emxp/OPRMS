package com.example.new1.Repository;

import com.example.new1.Model.Academic.DevelopmentGroup;
import com.example.new1.Model.Academic.OneToFiveGroup;
import com.example.new1.Model.Academic.Staff;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OneToFiveRepository extends JpaRepository<OneToFiveGroup, Integer> {
        OneToFiveGroup findById(int id);

        List<OneToFiveGroup> findByDepartment_Id(int id);

        List<OneToFiveGroup> findByDevelopmentGroupId(int id);

        List<OneToFiveGroup> findByLeader_Id(int id);

        List<OneToFiveGroup> findByGroupName(String name);


//        @Query("UPDATE OneToFiveGroup SET OneToFiveGroup.leader= leaderId WHERE OneToFiveGroup.id= id")
//        void save(@Param("leaderId") int leaderId, @Param("id") int id);
}
