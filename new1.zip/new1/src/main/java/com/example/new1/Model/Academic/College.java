package com.example.new1.Model.Academic;

import org.hibernate.validator.constraints.Length;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
public class College {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @NotEmpty(message = "መሞላት ያለበት መረጃ！")
    @Length(max = 100, message = "በዚህ መረጃ ላይ ከ100 ፊደሎች በላይ አይሞሉም！")
    @Pattern(regexp = "[A-z /s]*", message = "በዚህ መረጃ ላይ የEnglish ፊደሎች ብቻ ይሞላሉ！")
    private String college_Name;

    private Integer newPlans = 0;
    private Integer newReports = 0;

    public College() {
    }

    public College(String college_Name) {
        this.college_Name = college_Name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCollege_Name() {
        return college_Name;
    }

    public void setCollege_Name(String college_Name) {
        this.college_Name = college_Name;
    }

    public Integer getNewPlans() {
        return newPlans;
    }

    public void setNewPlans(Integer newPlans) {
        this.newPlans = newPlans;
    }

    public Integer getNewReports() {
        return newReports;
    }

    public void setNewReports(Integer newReports) {
        this.newReports = newReports;
    }

    public void incrementNewPlans() {
        setNewPlans(getNewPlans() + 1);
    }

    public void decrementNewPlans() {
        setNewPlans(getNewPlans() - 1);
    }

    public void incrementNewReports() {
        setNewReports(getNewReports() + 1);
    }

    public void decrementNewReports() {
        setNewReports(getNewReports() - 1);
    }
}
