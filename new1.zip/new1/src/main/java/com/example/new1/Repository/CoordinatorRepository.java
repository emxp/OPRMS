package com.example.new1.Repository;

import com.example.new1.Model.Academic.Coordinator;
import com.example.new1.Model.Academic.DepartmentHead;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CoordinatorRepository extends JpaRepository<Coordinator, Integer> {
    @Query("select c from Coordinator c order by c.department.dep_Name")
    List<Coordinator> findAllByOrOrderByDepartmentAsc();

    Coordinator findById(int id);
    void deleteById(int id);

    List<Coordinator> findByStaff_Id(int id);
}
