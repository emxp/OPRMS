package com.example.new1.Controller.staff;

import com.example.new1.Model.Academic.*;
import com.example.new1.Model.Security.Users;
import com.example.new1.Repository.*;
import com.example.new1.Repository.Security.RoleRepository;
import com.example.new1.Repository.Security.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping(value = "/staff")
@PreAuthorize("hasAnyRole('COORDINATOR')")
public class oneToFiveController {

    @Autowired
    private StaffRepository staffRepository;
    @Autowired
    private OneToFiveRepository oneToFiveRepository;
    @Autowired
    private DevelopmentRepository developmentRepository;
    @Autowired
    private DepHeadRepository depHeadRepository;
    @Autowired
    private DeanRepository deanRepository;
    @Autowired
    private UsersRepository usersRepository;
    @Autowired
    private RoleRepository roleRepository;

    static OneToFiveGroup tempOneToFiveGroup = new OneToFiveGroup();

    public Users getUser(){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return usersRepository.findUsersByUserName(auth.getName());
    }

    public List<Staff> nonLeaderStaffs(List<Staff> staffList){

        for (int i=0; i<staffList.size(); i++){
            if(!deanRepository.findByStaff_Id(staffList.get(i).getId()).isEmpty()){
                staffList.remove(i);
                i--;
                continue;
            }
            if(!depHeadRepository.findByStaff_Id(staffList.get(i).getId()).isEmpty()){
                staffList.remove(i);
                i--;
                continue;
            }
        }

        return staffList;
    }


    public List<Staff> groupLessStaffs(){
        Users user= getUser();

        List<Staff> staffList = staffRepository.findByDepartment_Id(user.getStaff().getDepartment().getId());
        List<Staff> staffs = new ArrayList<>();
        List<OneToFiveGroup> oneToFiveGroups = oneToFiveRepository.findAll();
        staffs.clear();

        if(oneToFiveGroups.isEmpty()){
            return nonLeaderStaffs(staffList);
        }else {
            for (int i = 0; i < oneToFiveGroups.size(); i++) {
                staffs.addAll(oneToFiveGroups.get(i).getOneToFiveMembers());
            }

            for (int j = 0; j < staffList.size(); j++) {
                if(staffs.contains(staffList.get(j))){
                    staffList.remove(j);
                    j--;
                }
            }
        }
        return nonLeaderStaffs(staffList);
    }

    @RequestMapping(value = "/addNewOneToFive")
    public String addOneToFive(OneToFiveGroup oneToFiveGroup, Model model ){
        Users user= getUser();

        List<Staff> staffList = groupLessStaffs();
        if(staffList.isEmpty()){
            List<DevelopmentGroup> developmentGroups = developmentRepository.findByDepartment_Id(user.getStaff().getDepartment().getId());
            model.addAttribute("cannotAdd", true);
            model.addAttribute("oneToFiveGroups", oneToFiveRepository.findByDepartment_Id(user.getStaff().getDepartment().getId()));
            model.addAttribute("developmentGroups", developmentGroups);
            model.addAttribute("user", user);

            if(developmentGroups.isEmpty()){
                model.addAttribute("emptyDev", true);
            }

            return "staff/staffCoordinator";
        }else {
            oneToFiveGroup.getOneToFiveMembers().add(new Staff());
            model.addAttribute("staffs", groupLessStaffs());
            model.addAttribute("user", user);
            return "staff/editOneToFive";
        }
    }

    @RequestMapping(value = {"/addOneToFive", "/addOneToFive/{id}"}, params = "addRow")
    public String addRow(OneToFiveGroup oneToFiveGroup , BindingResult bindingResult, Model model){
        List<Staff> staffs = groupLessStaffs();

        if(oneToFiveGroup.getId() == 0){
            System.out.println("qqqqqqqqqqqqqqqqqqqq");
            model.addAttribute("staffs", staffs);
            model.addAttribute("isEdit", false);
        }else{
            System.out.println("wwwwwwwwwwwwwwwwwwww");
            List<Staff> staffList = new ArrayList<>();
            staffList.addAll(staffs);
            staffList.addAll(oneToFiveRepository.findById(oneToFiveGroup.getId()).getOneToFiveMembers());
            model.addAttribute("staffs", staffList);
            model.addAttribute("isEdit", true);
        }

        if(oneToFiveGroup.getOneToFiveMembers().size() < 5){
            oneToFiveGroup.getOneToFiveMembers().add(new Staff());
        }

        model.addAttribute("user", getUser());
        return "staff/editOneToFive";
    }

    @RequestMapping(value = {"/addOneToFive", "/addOneToFive/{id}"}, params={"removeRow"})
    public String removeRow(final OneToFiveGroup oneToFiveGroup, final BindingResult bindingResult, final HttpServletRequest req, Model model) {
        if(oneToFiveGroup.getOneToFiveMembers().size() > 1){
            final Integer rowId = Integer.valueOf(req.getParameter("removeRow"));
            oneToFiveGroup.getOneToFiveMembers().remove(rowId.intValue());
        }

        List<Staff> staffs = groupLessStaffs();


        if(oneToFiveGroup.getId() == 0) {
            model.addAttribute("staffs", staffs);
            model.addAttribute("isEdit", false);
        }else{
            List<Staff> staffList = new ArrayList<>();
            staffList.addAll(staffs);
            staffList.addAll(oneToFiveGroup.getOneToFiveMembers());
            model.addAttribute("staffs", staffList);
            model.addAttribute("isEdit", true);
        }

        model.addAttribute("user", getUser());
        return "staff/editOneToFive";
    }

    @RequestMapping(value={"/addOneToFive", "/addOneToFive/{id}"})
    public String saveOnetoFive(@Valid OneToFiveGroup oneToFiveGroup, BindingResult bindingResult, ModelMap model) {
        if (bindingResult.hasErrors()) {
            loadingTheProperData(oneToFiveGroup, model);

            model.addAttribute("user", getUser());
            return "staff/editOneToFive";
        }

        List<Staff> staffs = oneToFiveGroup.getOneToFiveMembers();
        staffs = staffs.stream().distinct().collect(Collectors.toList());
        oneToFiveGroup.getOneToFiveMembers().clear();
        oneToFiveGroup.getOneToFiveMembers().addAll(staffs);
        model.addAttribute("oneToFiveGroup", oneToFiveGroup);
        model.addAttribute("staffs", staffs);

        tempOneToFiveGroup = oneToFiveGroup;

        model.addAttribute("user", getUser());
        return "staff/oneToFiveLeader";
    }

    private void loadingTheProperData(@Valid OneToFiveGroup oneToFiveGroup, ModelMap model) {
        if(oneToFiveGroup.getId() == 0){
            oneToFiveGroup = tempOneToFiveGroup;
            model.addAttribute("isEdit", false);
        }else{
            oneToFiveGroup = oneToFiveRepository.findById(oneToFiveGroup.getId());
            model.addAttribute("isEdit", true);
        }
        List<Staff> staffList = new ArrayList<>();
        staffList.addAll(groupLessStaffs());
        staffList.addAll(oneToFiveGroup.getOneToFiveMembers());
        model.addAttribute("staffs", staffList);
    }

    @RequestMapping(value={"/addOneToFive/{id}"}, params = "save")
    public String editOnetoFive(@Valid OneToFiveGroup oneToFiveGroup, BindingResult bindingResult, ModelMap model) {
        if (bindingResult.hasErrors()) {
            loadingTheProperDataInEditingMode(oneToFiveGroup, model);

            model.addAttribute("user", getUser());
            return "staff/editOneToFive";
        }

        if(oneToFiveGroup.getOneToFiveMembers().contains(oneToFiveGroup.getLeader())){
            List<Staff> staffs = oneToFiveGroup.getOneToFiveMembers();
            staffs = staffs.stream().distinct().collect(Collectors.toList());
            oneToFiveGroup.getOneToFiveMembers().clear();
            oneToFiveGroup.getOneToFiveMembers().addAll(staffs);
            Users user= getUser();
            oneToFiveGroup.setDepartment(user.getStaff().getDepartment());
            oneToFiveRepository.save(oneToFiveGroup);
            return "redirect:/staff/coordinator";
        }else {
            List<Staff> staffs = oneToFiveGroup.getOneToFiveMembers();
            staffs = staffs.stream().distinct().collect(Collectors.toList());
            oneToFiveGroup.getOneToFiveMembers().clear();
            oneToFiveGroup.getOneToFiveMembers().addAll(staffs);
            model.addAttribute("oneToFiveGroup", oneToFiveGroup);
            model.addAttribute("staffs", staffs);

            model.addAttribute("user", getUser());
            return "staff/oneToFiveLeader";
        }

    }

    private void loadingTheProperDataInEditingMode(@Valid OneToFiveGroup oneToFiveGroup, ModelMap model) {
        oneToFiveGroup = oneToFiveRepository.findById(oneToFiveGroup.getId());
        model.addAttribute("isEdit", true);
        List<Staff> staffList = new ArrayList<>();
        staffList.addAll(groupLessStaffs());
        staffList.addAll(oneToFiveGroup.getOneToFiveMembers());
        model.addAttribute("staffs", staffList);
    }

    @RequestMapping(value = "/editOneToFive/{id}")
    public String editOneToFive(@PathVariable int id, Model model){
        OneToFiveGroup oneToFiveGroup;
        if(id == 0){
            oneToFiveGroup = tempOneToFiveGroup;
            model.addAttribute("isEdit", false);
        }else{
            oneToFiveGroup = oneToFiveRepository.findById(id);
            model.addAttribute("isEdit", true);
        }
        List<Staff> staffList = new ArrayList<>();
        staffList.addAll(groupLessStaffs());
        staffList.addAll(oneToFiveGroup.getOneToFiveMembers());
        model.addAttribute("oneToFiveGroup", oneToFiveGroup);
        model.addAttribute("staffs", staffList);

        model.addAttribute("user", getUser());
        return "staff/editOneToFive";

    }

    public boolean isDevelopmentMember(OneToFiveGroup oneToFiveGroup){
        List<DevelopmentGroup> developmentGroups = developmentRepository.findAll();
        for (int i=0; i<developmentGroups.size(); i++){
            if(developmentGroups.get(i).getDevelopmentMembers().contains(oneToFiveGroup)){
                return true;
            }
        }
        return false;
    }

    @RequestMapping(value = "/deleteOneToFive/{id}")
    public String deleteOneToFive(@PathVariable int id, Model model){
        Users user= getUser();
        OneToFiveGroup oneToFiveGroup = oneToFiveRepository.findById(id);

        if(isDevelopmentMember(oneToFiveGroup)){
            model.addAttribute("isDevelopmentMember", true);
            model.addAttribute("OneToFive", oneToFiveGroup);
            model.addAttribute("oneToFiveGroups", oneToFiveRepository.findByDepartment_Id(user.getStaff().getDepartment().getId()));
            model.addAttribute("developmentGroups", developmentRepository.findByDepartment_Id(user.getStaff().getDepartment().getId()));

            model.addAttribute("user", getUser());
            return "staff/staffCoordinator";
        }else {

            // If the oneToFive group is removed first of all the user that have access to system
            // by using group id must be removed.
            // Bellow code is doing that.
            Users users = usersRepository.findByStaff(oneToFiveGroup.getLeader());
            users.getRoles().remove(roleRepository.findByRole("ONE_TO_FIVE"));
            users.setOneToFiveId(null);

            // If user have no role any more it must be removed.
            if(users.getRoles().isEmpty()){
                usersRepository.delete(users);
            }

            oneToFiveRepository.deleteById(id);
            return "redirect:/staff/coordinator";
        }
    }


    @RequestMapping(value="/makeOneToFiveLeader/{id}")
    public String makeOneToFiveLeader(OneToFiveGroup oneToFiveGroup) {
        Users user= getUser();
        oneToFiveGroup.setDepartment(user.getStaff().getDepartment());
        oneToFiveGroup.setDevelopmentGroup(tempOneToFiveGroup.getDevelopmentGroup());
        Staff oneToFiveLeader = oneToFiveGroup.getLeader();

        // oneToFiveGroup.getId() != 0 means we are in editing mode.
        // So the User with the role of development must be removed leaving the space for the new comer staff.
        // Bellow code is doing that.
        if(oneToFiveGroup.getId() != 0){
            Users users = usersRepository.findByStaff(tempOneToFiveGroup.getLeader());
            if(users.getDevelopmentId() != null){
                users.getRoles().remove(roleRepository.findByRole("DEVELOPMENT"));
                users.setDevelopmentId(null);
            }
        }

        // Deleting the user_role and user that have access with the oneToFive group id
        deleteOneToFiveLeader(oneToFiveGroup);

        oneToFiveRepository.save(oneToFiveGroup);

        // Saving the user with access of oneToFive group.
        OneToFiveGroup oneToFiveGroup1 =oneToFiveRepository.findById(oneToFiveGroup.getId());
        makeOneToFiveUser(oneToFiveGroup1, oneToFiveLeader);

        return "redirect:/staff/coordinator";
    }

    private void deleteOneToFiveLeader(OneToFiveGroup oneToFiveGroup) {
        if(oneToFiveGroup.getId() != 0){
            OneToFiveGroup oneToFiveGroup1 = oneToFiveRepository.findById(tempOneToFiveGroup.getId());

            Users users = usersRepository.findByStaff(oneToFiveGroup1.getLeader());
            users.getRoles().remove(roleRepository.findByRole("ONE_TO_FIVE"));
            users.setOneToFiveId(null);

            if(users.getRoles().isEmpty()){
                usersRepository.delete(users);
            }
        }
    }

    private void makeOneToFiveUser(OneToFiveGroup oneToFiveGroup, Staff oneToFiveLeader) {

        // Checking whether the new leader have no user account
        // then creating newUser account and give the access with the id of OneToFive group
        if(usersRepository.findByStaff(oneToFiveLeader) == null){
            Users users = new Users(1, oneToFiveLeader.getUserName(), oneToFiveLeader.getPassword(), oneToFiveLeader);
            users.setRole(roleRepository.findByRole("ONE_TO_FIVE"));
            users.setOneToFiveId(oneToFiveGroup);
            if(oneToFiveGroup.getDevelopmentGroup() != null){
                users.setRole(roleRepository.findByRole("DEVELOPMENT"));
                users.setDevelopmentId(oneToFiveGroup.getDevelopmentGroup());
            }
            usersRepository.save(users);
        }
        // Checking whether the new leader have user account
        // then add access with the id of OneToFive group.
        else if(usersRepository.findByStaff(oneToFiveLeader).getStaff() == oneToFiveLeader){
            Users users = usersRepository.findByStaff(oneToFiveLeader);
            users.setRole(roleRepository.findByRole("ONE_TO_FIVE"));
            users.setOneToFiveId(oneToFiveGroup);
            if(oneToFiveGroup.getDevelopmentGroup() != null){
                users.setRole(roleRepository.findByRole("DEVELOPMENT"));
                users.setDevelopmentId(oneToFiveGroup.getDevelopmentGroup());
            }
        }

        oneToFiveRepository.save(oneToFiveGroup);
    }
}
