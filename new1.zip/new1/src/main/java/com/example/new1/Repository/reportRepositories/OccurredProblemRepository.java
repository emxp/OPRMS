package com.example.new1.Repository.reportRepositories;

import com.example.new1.Model.reportRelated.OccurredProblem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OccurredProblemRepository extends JpaRepository<OccurredProblem, Integer> {

}
