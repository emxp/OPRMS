package com.example.new1.Controller.planRelated;

import com.example.new1.Model.Security.Users;
import com.example.new1.Model.planRelated.*;
import com.example.new1.Model.reportRelated.*;
import com.example.new1.Repository.CollegeRepository;
import com.example.new1.Repository.DepartmentRepository;
import com.example.new1.Repository.DevelopmentRepository;
import com.example.new1.Repository.Security.UsersRepository;
import com.example.new1.Repository.general.ScrollRepository;
import com.example.new1.Repository.planRepositories.*;
import com.example.new1.Repository.reportRepositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@Controller
@PreAuthorize("hasAnyRole('ONE_TO_FIVE', 'DEVELOPMENT', 'DEPARTMENT', 'DEAN')")
public class EditPlanController {

    @Autowired
    PlanJpaRepository planJpaRepository;

    @Autowired
    Plan1JpaRepository plan1JpaRepository;

    @Autowired
    Plan2JpaRepository plan2JpaRepository;

    @Autowired
    Plan3JpaRepository plan3JpaRepository;

    @Autowired
    Plan4JpaRepository plan4JpaRepository;

    @Autowired
    Plan5JpaRepository plan5JpaRepository;


    @Autowired
    Report1JpaRepository report1JpaRepository;

    @Autowired
    Report2JpaRepository report2JpaRepository;

    @Autowired
    Report3JpaRepository report3JpaRepository;

    @Autowired
    Report4JpaRepository report4JpaRepository;

    @Autowired
    Report5JpaRepository report5JpaRepository;

    @Autowired
    ScrollRepository scrollRepository;

    @Autowired
    UsersRepository usersRepository;

    @Autowired
    DevelopmentRepository developmentRepository;

    @Autowired
    DepartmentRepository departmentRepository;

    @Autowired
    CollegeRepository collegeRepository;

    List<String> whichOneIsClicked = new ArrayList<>();

    private Users getUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return usersRepository.findUsersByUserName(auth.getName());
    }

    @RequestMapping({"/editPlan", "/addEditRow"})
    public String editAPlan(Plan plan, BindingResult bindingResult, ModelMap modelMap) {
        whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();
        modelMap.put("whichOneIsClicked", whichOneIsClicked);
        modelMap.put("user", getUser());
        return "editPlan";
    }

    @RequestMapping("/editPlan/{id}")
    public String editASinglePlan(Plan plan, BindingResult bindingResult, @PathVariable int id, ModelMap modelMap) {
        whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();
        plan = planJpaRepository.getOne(id);

        modelMap.put("plan", plan);
        modelMap.put("whichOneIsClicked", whichOneIsClicked);
        modelMap.put("user", getUser());
        return "editPlan";
    }


    @RequestMapping(value = "/addEditRow", params = {"newline"})
    public String addRow(Plan plan, BindingResult bindingResult, HttpServletRequest request, ModelMap modelMap) {
        whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();
        switch (request.getParameter("newline")) {
            case "plan1":
                plan.getPlan1s().add(new Plan1());
                whichOneIsClicked.set(0, "theClickedBtn");
                break;
            case "plan2":
                plan.getPlan2s().add(new Plan2());
                whichOneIsClicked.set(1, "theClickedBtn");
                break;
            case "plan3":
                plan.getPlan3s().add(new Plan3());
                whichOneIsClicked.set(2, "theClickedBtn");
                break;
            case "plan4":
                plan.getPlan4s().add(new Plan4());
                whichOneIsClicked.set(3, "theClickedBtn");
                break;
            case "plan5":
                plan.getPlan5s().add(new Plan5());
                whichOneIsClicked.set(4, "theClickedBtn");
                break;
        }
        modelMap.put("whichOneIsClicked", whichOneIsClicked);
        modelMap.put("user", getUser());
        return "editPlan";
    }

    @RequestMapping(value = "/addEditRow", params = {"dropline"})
    public String removeRow(Plan plan, BindingResult bindingResult, HttpServletRequest request, ModelMap modelMap) {
        whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();
        int dotPosition = request.getParameter("dropline").indexOf('.');
        Integer toBeRemovedIndex = Integer.valueOf(request.getParameter("dropline").substring(1, dotPosition));
        System.out.println("\nqqqqqqqqqqqq " + toBeRemovedIndex.intValue());
        Integer toBeRemovedId = Integer.valueOf(request.getParameter("dropline").substring(dotPosition + 1));
        System.out.println("QQQQQQQQQQQQ " + toBeRemovedId.intValue());


        switch (request.getParameter("dropline").substring(0, 1)) {
            case "1":
                if (toBeRemovedId.intValue() == 0)
                    plan.getPlan1s().remove(toBeRemovedIndex.intValue());
                else {
                    for (Report1 report1 : report1JpaRepository.findAll()) {        //first delete the corresponding report;
                        if(report1.getId() == toBeRemovedId) {
                            report1JpaRepository.delete(report1);
                            break;
                        }
                    }
                    plan.getPlan1s().remove(toBeRemovedIndex.intValue());
                    plan1JpaRepository.deleteById(toBeRemovedId.intValue());
                }
                whichOneIsClicked.set(0, "theClickedBtn");
                break;
            case "2":
                if (toBeRemovedId.intValue() == 0)
                    plan.getPlan2s().remove(toBeRemovedIndex.intValue());
                else {
                    for (Report2 report2 : report2JpaRepository.findAll()) {        //first delete the corresponding report;
                        if(report2.getId() == toBeRemovedId) {
                            report2JpaRepository.delete(report2);
                            break;
                        }
                    }
                    plan.getPlan2s().remove(toBeRemovedIndex.intValue());
                    plan2JpaRepository.deleteById(toBeRemovedId.intValue());
                }
                whichOneIsClicked.set(1, "theClickedBtn");
                break;
            case "3":
                if (toBeRemovedId.intValue() == 0)
                    plan.getPlan3s().remove(toBeRemovedIndex.intValue());
                else {
                    for (Report3 report3 : report3JpaRepository.findAll()) {        //first delete the corresponding report;
                        if(report3.getId() == toBeRemovedId) {
                            report3JpaRepository.delete(report3);
                            break;
                        }
                    }
                    plan.getPlan3s().remove(toBeRemovedIndex.intValue());
                    plan3JpaRepository.deleteById(toBeRemovedId.intValue());
                }
                whichOneIsClicked.set(2, "theClickedBtn");
                break;
            case "4":
                if (toBeRemovedId.intValue() == 0)
                    plan.getPlan4s().remove(toBeRemovedIndex.intValue());
                else {
                    for (Report4 report4 : report4JpaRepository.findAll()) {        //first delete the corresponding report;
                        if(report4.getId() == toBeRemovedId) {
                            report4JpaRepository.delete(report4);
                            break;
                        }
                    }
                    plan.getPlan4s().remove(toBeRemovedIndex.intValue());
                    plan4JpaRepository.deleteById(toBeRemovedId.intValue());
                }
                whichOneIsClicked.set(3, "theClickedBtn");
                break;
            case "5":
                if (toBeRemovedId.intValue() == 0)
                    plan.getPlan5s().remove(toBeRemovedIndex.intValue());
                else {
                    for (Report5 report5 : report5JpaRepository.findAll()) {        //first delete the corresponding report;
                        if(report5.getId() == toBeRemovedId) {
                            report5JpaRepository.delete(report5);
                            break;
                        }
                    }
                    plan.getPlan5s().remove(toBeRemovedIndex.intValue());
                    plan5JpaRepository.deleteById(toBeRemovedId.intValue());
                }
                whichOneIsClicked.set(4, "theClickedBtn");
                break;
            default:
                break;
        }

        modelMap.put("whichOneIsClicked", whichOneIsClicked);

        modelMap.put("user", getUser());
        return "editPlan";
    }


    @RequestMapping(value = "/addEditRow", params = {"saveAllEditedData"}, method = RequestMethod.POST)
    public String saveAllPlans(@Valid Plan plan, BindingResult bindingResult, ModelMap modelMap) {

        if (bindingResult.hasErrors()) {
            whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();

            modelMap.put("plan", plan);
            modelMap.put("whichOneIsClicked", whichOneIsClicked);

            modelMap.put("user", getUser());
            return "editPlan";
        }

        if (!plan.isNewPlan())
            incrementNewlyCreatedPlans(plan, plan.getReceiverGroupId());

        if(plan.isNewPlan()){
            plan.setNewPlan(false);
        }

        planJpaRepository.save(plan);

        return "redirect:/plansList";
    }

    public void incrementNewlyCreatedPlans(Plan plan, Integer receiverId) {
        if (!plan.isNewPlan()){         //if the to edited plan in not a new plan, then set it new;
            if (((getUser().getOneToFiveId() != null) && (getUser().getOneToFiveId().getDevelopmentGroup() != null))) {     //if the sender is 125 leader AND Only INVOLVED(not leading) in some development group and sending to the development group; Or works also for a development leader also, who is sending to the development that he is in or he leads;
                if (getUser().getOneToFiveId().getDevelopmentGroup().getId() == receiverId) {
                    getUser().getOneToFiveId().getDevelopmentGroup().incrementNewPlans();
                    developmentRepository.save(getUser().getOneToFiveId().getDevelopmentGroup());
                }
            }
            if (getUser().getDevelopmentId() != null) {     //if the sender is a development leader and he is sending to the department that his development is in;
                if (getUser().getDevelopmentId().getDepartment().getId() == receiverId) {
                    getUser().getDevelopmentId().getDepartment().incrementNewPlans();
                    departmentRepository.save(getUser().getDevelopmentId().getDepartment());
                }
            }
            if (getUser().getHeadDepartmentId() != null) {     //if the sender is a department head and he is sending to the college his department is in;
                if (getUser().getHeadDepartmentId().getCollege().getId() == receiverId) {
                    getUser().getHeadDepartmentId().getCollege().incrementNewPlans();
                    collegeRepository.save(getUser().getHeadDepartmentId().getCollege());
                }
            }
            plan.setNewPlan(true);
            planJpaRepository.save(plan);
        }
    }

}
