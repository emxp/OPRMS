package com.example.new1.Model.reportRelated;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "unsolved_problem", catalog = "test")
public class UnsolvedProblem {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @NotEmpty(message = "መረጃ ማስገባት አለብዎት!")
    @Column(columnDefinition = "TEXT")
    private String content;

    @Column(name = "report_id", insertable = false, updatable = false)
    private int reportId;


    public UnsolvedProblem(String content) {
        this.content = content;
    }

    public UnsolvedProblem() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getReportId() {
        return reportId;
    }

    public void setReportId(int reportId) {
        this.reportId = reportId;
    }
}
