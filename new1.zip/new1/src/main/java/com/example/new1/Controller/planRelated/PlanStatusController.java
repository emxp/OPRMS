package com.example.new1.Controller.planRelated;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import com.example.new1.Model.planRelated.*;
import com.example.new1.Repository.planRepositories.*;

@Controller
@PreAuthorize("hasAnyRole('ONE_TO_FIVE', 'DEVELOPMENT', 'DEPARTMENT', 'DEAN')")
public class PlanStatusController {

    @Autowired
    PlanJpaRepository planJpaRepository;

    @RequestMapping(value = "/subMirmeras", params = {"saveAllStatusData"})
    public String saveMirmeras(Plan plan, BindingResult bindingResult, ModelMap modelMap) {

        if(plan.isNewPlan()){
            plan.setNewPlan(false);
        }

        planJpaRepository.save(plan);
        return "redirect:/plansList";
    }


}
