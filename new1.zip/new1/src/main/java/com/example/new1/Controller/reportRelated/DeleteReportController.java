package com.example.new1.Controller.reportRelated;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import com.example.new1.Repository.reportRepositories.ReportJpaRepository;

@Controller
@PreAuthorize("hasAnyRole('ONE_TO_FIVE', 'DEVELOPMENT', 'DEPARTMENT', 'DEAN')")
public class DeleteReportController {

    @Autowired
    ReportJpaRepository reportJpaRepository;

    @RequestMapping("/delete/{id}")
    public String deleteASingleReport(@PathVariable int id) {

        reportJpaRepository.deleteById(Integer.valueOf(id));

        return "redirect:/reportsList";
    }

}
