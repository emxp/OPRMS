package com.example.new1.Model.Academic;

import org.hibernate.validator.constraints.Length;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import java.util.ArrayList;
import java.util.List;

@Entity
public class DevelopmentGroup {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @NotEmpty(message = "መሞላት ያለበት መረጃ！")
    @Length(max = 45, message = "በዚህ መረጃ ላይ ከ45 ፊደሎች በላይ አይሞሉም！")
    @Pattern(regexp = "[A-z 0-9 /s]*", message = "በዚህ መረጃ ላይ የEnglish ፊደሎች እና ቁጥሮች ብቻ ይሞላሉ！")
    private String groupName;

    @OneToOne
    @JoinColumn(name = "leader_id", referencedColumnName = "id")
    private OneToFiveGroup leader;

    @OneToOne
    @JoinColumn(name = "department_id", referencedColumnName = "id")
    private Department department;

    @ManyToMany
    @JoinTable(name="DevelopmentGroupMembers",joinColumns = @JoinColumn(name="id"),inverseJoinColumns = @JoinColumn(name="leader"))
    private List<OneToFiveGroup> developmentMembers = new ArrayList<>();

    private Integer newPlans = 0;
    private Integer newReports = 0;

    public DevelopmentGroup() {
    }
    public DevelopmentGroup(int id) {
        this.id = id;
    }

    public DevelopmentGroup(String groupName, OneToFiveGroup leader, Department department, List<OneToFiveGroup> developmentMembers) {
        this.groupName = groupName;
        this.leader = leader;
        this.department = department;
        this.developmentMembers = developmentMembers;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public OneToFiveGroup getLeader() {
        return leader;
    }

    public void setLeader(OneToFiveGroup leader) {
        this.leader = leader;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public List<OneToFiveGroup> getDevelopmentMembers() {
        return developmentMembers;
    }

    public void setDevelopmentMembers(List<OneToFiveGroup> developmentMembers) {
        this.developmentMembers = developmentMembers;
    }

    public Integer getNewPlans() {
        return newPlans;
    }

    public void setNewPlans(Integer newPlans) {
        this.newPlans = newPlans;
    }

    public Integer getNewReports() {
        return newReports;
    }

    public void setNewReports(Integer newReports) {
        this.newReports = newReports;
    }

    public void incrementNewPlans() {
        setNewPlans(getNewPlans() + 1);
    }

    public void decrementNewPlans() {
        setNewPlans(getNewPlans() - 1);
    }

    public void incrementNewReports() {
        setNewReports(getNewReports() + 1);
    }

    public void decrementNewReports() {
        setNewReports(getNewReports() - 1);
    }

}
