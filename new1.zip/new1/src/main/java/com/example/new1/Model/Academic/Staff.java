package com.example.new1.Model.Academic;

import com.example.new1.Model.Academic.Department;
import org.hibernate.validator.constraints.Length;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@Entity
public class Staff {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String uniId;

    @NotEmpty(message = "መሞላት ያለበት መረጃ！")
    @Length(max = 20, message = "በዚህ መረጃ ላይ ከ20 ፊደሎች በላይ አይሞሉም！")
    @Pattern(regexp = "[A-z /s]*", message = "በዚህ መረጃ ላይ የEnglish ፊደሎች ብቻ ይሞላሉ！")
    private String first_Name;

    @NotEmpty(message = "መሞላት ያለበት መረጃ！")
    @Length(max = 20, message = "በዚህ መረጃ ላይ ከ20 ፊደሎች በላይ አይሞሉም！")
    @Pattern(regexp = "[A-z /s]*", message = "በዚህ መረጃ ላይ የEnglish ፊደሎች ብቻ ይሞላሉ！")
    private String middle_Name;

    @NotEmpty(message = "መሞላት ያለበት መረጃ！")
    @Length(max = 20, message = "በዚህ መረጃ ላይ ከ20 ፊደሎች በላይ አይሞሉም！")
    @Pattern(regexp = "[A-z /s]*", message = "በዚህ መረጃ ላይ የEnglish ፊደሎች ብቻ ይሞላሉ！")
    private String last_Name;

    @NotEmpty(message = "መሞላት ያለበት መረጃ！")
    @Length(max = 20, message = "በዚህ መረጃ ላይ ከ20 ፊደሎች በላይ አይሞሉም！")
    @Pattern(regexp = "[A-z /s]*", message = "በዚህ መረጃ ላይ የEnglish ፊደሎች ብቻ ይሞላሉ！")
    private String acca_Status;

    private String userName;
    private String password;

    @ManyToOne
    @JoinColumn(name = "department_id", referencedColumnName = "id")
    private Department department;

    public Staff() {
    }

    public Staff(String acca_Status, String first_Name, String last_Name, String middle_Name, String uniId, String userName, String password, Department department) {
        this.uniId = uniId;
        this.first_Name = first_Name;
        this.middle_Name = middle_Name;
        this.last_Name = last_Name;
        this.acca_Status = acca_Status;
        this.userName = userName;
        this.password = password;
        this.department = department;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUniId() {
        return uniId;
    }

    public void setUniId(String uniId) {
        this.uniId = uniId;
    }

    public String getFirst_Name() {
        return first_Name;
    }

    public void setFirst_Name(String first_Name) {
        this.first_Name = first_Name;
    }

    public String getMiddle_Name() {
        return middle_Name;
    }

    public void setMiddle_Name(String middle_Name) {
        this.middle_Name = middle_Name;
    }

    public String getLast_Name() {
        return last_Name;
    }

    public void setLast_Name(String last_Name) {
        this.last_Name = last_Name;
    }

    public String getAcca_Status() {
        return acca_Status;
    }

    public void setAcca_Status(String acca_Status) {
        this.acca_Status = acca_Status;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public String getFullName(){
        return first_Name + " " + middle_Name + " " + last_Name;
    }

    public String getFormalName(){
        return first_Name + " " + middle_Name;
    }

    public String getFullNameAndID(){
        return first_Name + " " + middle_Name + " " + last_Name + " - ( " + uniId + " ) ";
    }
}
