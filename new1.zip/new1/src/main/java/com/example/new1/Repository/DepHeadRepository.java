package com.example.new1.Repository;

import com.example.new1.Model.Academic.Dean;
import com.example.new1.Model.Academic.DepartmentHead;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface DepHeadRepository extends JpaRepository<DepartmentHead, Integer> {
    @Query("select d from DepartmentHead d order by d.department.dep_Name")
    List<DepartmentHead> findAllByOrOrderByDepartmentAsc();

    DepartmentHead findById(int id);
    void deleteById(int id);

    List<DepartmentHead> findByStaff_Id(int id);
}
