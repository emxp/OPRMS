package com.example.new1.Model.Administration;

import com.example.new1.Model.Academic.Staff;

import javax.persistence.*;

@Entity
public class President {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @ManyToOne
    @JoinColumn(name = "staff_id", referencedColumnName = "id")
    private AdminStaff adminStaff;

    public President() {
    }

    public President(AdminStaff adminStaff) {
        this.adminStaff = adminStaff;
    }

    public int getId() {
        return id;
    }

    public AdminStaff getAdminStaff() {
        return adminStaff;
    }

    public void setAdminStaff(AdminStaff adminStaff) {
        this.adminStaff = adminStaff;
    }
}
