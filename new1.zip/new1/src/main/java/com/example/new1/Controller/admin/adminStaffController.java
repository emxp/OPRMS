package com.example.new1.Controller.admin;

import com.example.new1.Model.Academic.College;
import com.example.new1.Model.Academic.Department;
import com.example.new1.Model.Academic.Staff;
import com.example.new1.Repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.List;

@Controller
@RequestMapping(value = "/admin")
@PreAuthorize("hasAnyRole('ADMIN')")
public class adminStaffController {

    @Autowired
    private StaffRepository staffRepository;
    @Autowired
    private DepartmentRepository departmentRepository;
    @Autowired
    private DeanRepository deanRepository;
    @Autowired
    private DepHeadRepository depHeadRepository;
    @Autowired
    private CoordinatorRepository coordinatorRepository;

    @RequestMapping("/staffs")
    public String listStaff(ModelMap modelMap) {
        List<Staff> allStaff = staffRepository.findAllByOrderByFirst_NameAsc();
        modelMap.put("staffs", allStaff);
        return "admin/adminInfo";
    }

    @RequestMapping(value = "/{id}/editStaff", params = "edit=true")
    public String editStaff(@PathVariable int id, Model model){
        Staff staff = staffRepository.findById(id);
        List<Department> departments = departmentRepository.findAllByOrderByDep_NameAsc();
        model.addAttribute("departments", departments);
        model.addAttribute("staff", staff);
        model.addAttribute("isEdit", true);
        return "admin/editStaff";
    }
    @RequestMapping(value = "/addStaff")
    public String newStaff(ModelMap modelMap){
        List<Department> allDepartment = departmentRepository.findAllByOrderByDep_NameAsc();
        modelMap.put("departments", allDepartment);
        modelMap.put("staff", new Staff());
        modelMap.put("isEdit", false);
        return "admin/editStaff";
    }

    @PostMapping(value = {"/staffs/staff", "/staffs/staff/{id}"})
    public String addStaff(@Valid Staff staff, BindingResult bindingResult, Model model){
        if (bindingResult.hasErrors()) {
            List<Department> allDepartment = departmentRepository.findAllByOrderByDep_NameAsc();
            model.addAttribute("departments", allDepartment);
            if(staff.getId() == 0){
                model.addAttribute("isEdit", false);
            }else{
                model.addAttribute("isEdit", true);
            }
            return "admin/editStaff";
        }
        if(staff.getId() == 0){
            staffRepository.save(staff);
            Staff staff1 = staffRepository.findById(staff.getId());
            staff1.setUniId("AASTU0"+staff1.getId());
            staff1.setUserName("AASTU0"+staff1.getId());
            staff1.setPassword("AASTU0"+staff1.getId());
            staffRepository.save(staff1);
        }
        staffRepository.save(staff);
        return "redirect:/admin/staffs";
    }

    @RequestMapping(value = "/{id}/deleteStaff")
    public String deleteStaff(@PathVariable int id, Model model){
        if(deanRepository.findByStaff_Id(id).isEmpty() && depHeadRepository.findByStaff_Id(id).isEmpty() && coordinatorRepository.findByStaff_Id(id).isEmpty()){
            staffRepository.deleteById(id);
            return "redirect:/admin/staffs";
        }else {
            List<Staff> allStaff = staffRepository.findAllByOrderByFirst_NameAsc();
            Staff staff= staffRepository.findById(id);
            model.addAttribute("staffs", allStaff);
            model.addAttribute("deletedStaff", staff);
            model.addAttribute("canNotDelete", true);
            return "admin/adminInfo";
        }
    }
}
