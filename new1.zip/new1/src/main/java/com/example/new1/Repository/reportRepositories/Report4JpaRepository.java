package com.example.new1.Repository.reportRepositories;

import com.example.new1.Model.reportRelated.Report4;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

@Component
public interface Report4JpaRepository extends JpaRepository<Report4, Integer> {
}
