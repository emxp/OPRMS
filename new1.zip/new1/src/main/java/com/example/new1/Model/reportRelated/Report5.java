package com.example.new1.Model.reportRelated;

import com.example.new1.Model.planRelated.Plan5;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@Entity
public class Report5 {
    @Id
    private int id;

    @Column(name = "report_id", insertable = false, updatable = false)
    private int reportId;

    @Min(value = 0, message = "ከዜሮ ማነስ የለበትም!")
    @Max(value = 100, message = "ከመቶ መብለጥ የለበትም!")
    @NotNull(message = "አፈፃፀም ያስገቡ!")
    private Integer percentage;

    @Column(columnDefinition = "TEXT")
    private String ifNotWhy;

    @OneToOne()
    @JoinColumn(name = "id", referencedColumnName = "id")
    private Plan5 plan5;

    public Report5() {
    }

    public Report5(int id, Plan5 plan5) {
        this.id = id;
        this.plan5 = plan5;
    }

    public int getId() {
        return id;
    }

    public int getReportId() {
        return reportId;
    }

    public String getIfNotWhy() {
        return ifNotWhy;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setReportId(int reportId) {
        this.reportId = reportId;
    }

    public void setIfNotWhy(String ifNotWhy) {
        this.ifNotWhy = ifNotWhy;
    }

    public Plan5 getPlan5() {
        return plan5;
    }

    public void setPlan5(Plan5 plan5) {
        this.plan5 = plan5;
    }

    public Integer getPercentage() {
        return percentage;
    }

    public void setPercentage(Integer percentage) {
        this.percentage = percentage;
    }
}
