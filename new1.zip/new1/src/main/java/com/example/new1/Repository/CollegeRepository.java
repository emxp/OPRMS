package com.example.new1.Repository;

import com.example.new1.Model.Academic.College;
import com.example.new1.Model.Academic.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CollegeRepository extends JpaRepository<College, Integer> {
    College findById(int id);
    void deleteById(int id);

    @Query("select c from College c order by c.college_Name")
    List<College> findAllByOrderByCollege_NameAsc();
}
