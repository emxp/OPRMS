package com.example.new1.BootLoad;

import com.example.new1.Model.Academic.College;
import com.example.new1.Model.Academic.Department;
import com.example.new1.Model.Academic.Staff;
import com.example.new1.Model.Security.Role;
import com.example.new1.Model.Security.Users;
import com.example.new1.Repository.CollegeRepository;
import com.example.new1.Repository.DepartmentRepository;
import com.example.new1.Repository.Security.RoleRepository;
import com.example.new1.Repository.Security.UsersRepository;
import com.example.new1.Repository.StaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataLoader implements ApplicationListener<ContextRefreshedEvent>{

    @Autowired
    private CollegeRepository collegeRepository;
    @Autowired
    private DepartmentRepository departmentRepository;
    @Autowired
    private RoleRepository roleRepository;
    @Autowired
    private StaffRepository staffRepository;
    @Autowired
    private UsersRepository usersRepository;

    @Override
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {

        Role role = new Role("ADMIN");
        Role role2 = new Role("ONE_TO_FIVE");
        Role role3 = new Role("DEVELOPMENT");
        Role role4 = new Role("COORDINATOR");
        Role role5 = new Role("DEPARTMENT");
        Role role6 = new Role("DEAN");

        if(roleRepository.findAll().isEmpty()){
            roleRepository.save(role);
            roleRepository.save(role2);
            roleRepository.save(role3);
            roleRepository.save(role4);
            roleRepository.save(role5);
            roleRepository.save(role6);
        }

        Users user = new Users(1, "aaa", "aaa", null);
        if(usersRepository.findAll().isEmpty()){
            usersRepository.save(user);
            user.setRole(role);
            user.setAdminId(1);
            usersRepository.save(user);
        }


        College college = new College("College Of Electrical and Mechanical");
        College college1 = new College("College Of Civil and Architectural");
        College college2 = new College("College Of Chemical and Biological");
        College college3 = new College("College Of Computational and Social Studies");
        College college4 = new College("College Of Applied Science");

        if(collegeRepository.findAll().isEmpty()){
            collegeRepository.save(college);
            collegeRepository.save(college1);
            collegeRepository.save(college2);
            collegeRepository.save(college3);
            collegeRepository.save(college4);
        }

        Department department = new Department("Software Engineering", college);
        Department department2 = new Department("Electrical Engineering", college);
        Department department3 = new Department("Mechanical Engineering", college);
        Department department4 = new Department("ElectroMechanical Engineering", college);
        Department department5 = new Department("Civil Engineering", college1);
        Department department6 = new Department("Architectural Engineering", college1);
        Department department7 = new Department("Chemical Engineering", college2);
        Department department8 = new Department("BioTechnology", college2);
        Department department9 = new Department("COTEM", college1);
        Department department10 = new Department("Business Administration", college3);
        Department department11 = new Department("Accounting", college3);
        Department department12 = new Department("Economics", college3);
        Department department13 = new Department("Industrial Chemistry", college2);
        Department department14 = new Department("Physics", college4);
        Department department15 = new Department("Chemistry", college4);
        Department department16 = new Department("Biology", college4);

        if(departmentRepository.findAll().isEmpty()){
            departmentRepository.save(department);
            departmentRepository.save(department2);
            departmentRepository.save(department3);
            departmentRepository.save(department4);
            departmentRepository.save(department5);
            departmentRepository.save(department6);
            departmentRepository.save(department7);
            departmentRepository.save(department8);
            departmentRepository.save(department9);
            departmentRepository.save(department10);
            departmentRepository.save(department11);
            departmentRepository.save(department12);
            departmentRepository.save(department13);
            departmentRepository.save(department14);
            departmentRepository.save(department15);
            departmentRepository.save(department16);
        }

        if(staffRepository.findAll().isEmpty()){
            Staff staff = new Staff("BSc", "Endriyas", "Masresha", "Yeshidniber", "aastu29", "aastu29", "aastu29", department);
            Staff staff2 = new Staff("MSc", "Eleni", "Mengistu", "Teshome", "aastu30", "aastu30", "aastu30", department);
            Staff staff3 = new Staff("Dr", "Deepak", "Durga", "Sinha", "aastu31", "aastu31", "aastu31", department);
            Staff staff4 = new Staff("MSc", "Biruk ", "Wochiso", "Mulatu", "aastu32", "aastu32", "aastu32", department);
            Staff staff5 = new Staff("BSc", "Muluken", "Amdie", "Getachew", "aastu33", "aastu33", "aastu33", department);
            Staff staff6 = new Staff("BSc", "Biruk ", "Sharew", "Mammo", "aastu34", "aastu34", "aastu34", department);
            Staff staff7 = new Staff("BSc", "Biruk", "Baye", "Fekade", "aastu35", "aastu35", "aastu35", department7);
            Staff staff8 = new Staff("BSc", "Kidus", "Worku", "Fiker", "aastu36", "aastu36", "aastu36", department);
            Staff staff9 = new Staff("BSc", "Estifanos", "Yimam", "Alemseged", "aastu37", "aastu37", "aastu37", department);
            Staff staff10 = new Staff("BSc", "Eshetie", "Debebe", "Gashaw", "aastu38", "aastu38", "aastu38", department4);
            Staff staff11 = new Staff("MSc", "Samuel", "Abera", "Girma", "aastu39", "aastu39", "aastu39", department6);
            Staff staff12 = new Staff("Dr", "Sultan", "Yimam", "Ali", "aastu40", "aastu40", "aastu40", department);
            Staff staff13 = new Staff("BSc", "Hiskias", "Dingeto", "Melke", "aastu41", "aastu41", "aastu41", department4);
            Staff staff14 = new Staff("MSc", "Eyob", "Abegaz", "Worku", "aastu42", "aastu42", "aastu42", department6);
            Staff staff15 = new Staff("MSc", "Addis", "BashahEder", "Mengesha", "aastu43", "aastu43", "aastu43", department13);

            staffRepository.save(staff);
            staffRepository.save(staff2);
            staffRepository.save(staff3);
            staffRepository.save(staff4);
            staffRepository.save(staff5);
            staffRepository.save(staff6);
            staffRepository.save(staff7);
            staffRepository.save(staff8);
            staffRepository.save(staff9);
            staffRepository.save(staff10);
            staffRepository.save(staff11);
            staffRepository.save(staff12);
            staffRepository.save(staff13);
            staffRepository.save(staff14);
            staffRepository.save(staff15);
        }

    }
}
