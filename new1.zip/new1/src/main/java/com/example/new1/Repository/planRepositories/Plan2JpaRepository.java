package com.example.new1.Repository.planRepositories;

import com.example.new1.Model.planRelated.Plan2;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

@Component
public interface Plan2JpaRepository extends JpaRepository<Plan2, Integer> {
}
