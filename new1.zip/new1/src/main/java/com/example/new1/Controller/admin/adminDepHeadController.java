package com.example.new1.Controller.admin;

import com.example.new1.Model.Academic.*;
import com.example.new1.Model.Security.Users;
import com.example.new1.Repository.DeanRepository;
import com.example.new1.Repository.DepHeadRepository;
import com.example.new1.Repository.DepartmentRepository;
import com.example.new1.Repository.Security.RoleRepository;
import com.example.new1.Repository.Security.UsersRepository;
import com.example.new1.Repository.StaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping(value = "/admin")
@PreAuthorize("hasAnyRole('ADMIN')")
public class adminDepHeadController {

    @Autowired
    private DepHeadRepository depHeadRepository;
    @Autowired
    private DepartmentRepository departmentRepository;
    @Autowired
    private StaffRepository staffRepository;
    @Autowired
    private DeanRepository deanRepository;
    @Autowired
    private UsersRepository usersRepository;
    @Autowired
    private RoleRepository roleRepository;

    @RequestMapping("/depHeads")
    public String listDepHeads(ModelMap modelMap){
        List<DepartmentHead> allDepartmentHeads = depHeadRepository.findAllByOrOrderByDepartmentAsc();
        modelMap.put("depHeads", allDepartmentHeads);
        return "admin/adminDepHead";
    }

    @RequestMapping(value = "/addDepHead")
    public String addDepHead(Model model){
        List<Department> departments = getNonDepHeadDepartments();
        List<Staff> staffs = getNonDepHeadStaffs();
        if(departments.isEmpty()){
            List<DepartmentHead> allDepartmentHeads = depHeadRepository.findAllByOrOrderByDepartmentAsc();
            model.addAttribute("depHeads", allDepartmentHeads);
            model.addAttribute("isEmpty", true);
            return "admin/adminDepHead";
        }else if(staffs.isEmpty()){
            List<DepartmentHead> allDepartmentHeads = depHeadRepository.findAllByOrOrderByDepartmentAsc();
            model.addAttribute("depHeads", allDepartmentHeads);
            model.addAttribute("isStaffEmpty", true);
            return "admin/adminDepHead";
        }else {
            model.addAttribute("departments", departments);
            model.addAttribute("staffs", staffs);
            model.addAttribute("depHead", new DepartmentHead());
            model.addAttribute("isEdit", false);
            return "admin/editDepHead";
        }
    }

    public List<Department> getNonDepHeadDepartments(){
        List<Department> departments = departmentRepository.findAllByOrderByDep_NameAsc();
        List<DepartmentHead> departmentHeads = depHeadRepository.findAll();
        List<Department> depHeadDepartment = new ArrayList<>();
        for (int i=0; i<departmentHeads.size(); i++){
            depHeadDepartment.add(departmentHeads.get(i).getDepartment());
        }
        for (int i=0; i<departments.size(); i++) {
            if(depHeadDepartment.contains(departments.get(i))){
                departments.remove(departments.get(i));
                i--;        //because when item remove the structure of list is changed. so we have to move back at every remove!
            }
        }
        return departments;
    }
    public List<Staff> getNonDepHeadStaffs(){
        List<Staff> staffs = staffRepository.findAllByOrderByFirst_NameAsc();
        List<DepartmentHead> departmentHeads = depHeadRepository.findAll();
        List<Dean> deans = deanRepository.findAll();
        List<Staff> depHeadStaff = new ArrayList<>();
        for (int i=0; i<departmentHeads.size(); i++){
            depHeadStaff.add(departmentHeads.get(i).getStaff());
        }
        for (int i=0; i<deans.size(); i++){
            depHeadStaff.add(deans.get(i).getStaff());
        }
        for (int i=0; i<staffs.size(); i++) {
            if(depHeadStaff.contains(staffs.get(i))){
                staffs.remove(staffs.get(i));
                i--;        //because when item remove the structure of list is changed. so we have to move back at every remove!
            }
        }
        return staffs;
    }
    public List<Staff> getNonDepHeadStaffs(Department department){
        List<Staff> staffs = staffRepository.findAllByOrderByFirst_NameAsc();
        List<DepartmentHead> departmentHeads = depHeadRepository.findAll();
        List<Dean> deans = deanRepository.findAll();
        List<Staff> depHeadStaff = new ArrayList<>();
        for (int i=0; i<departmentHeads.size(); i++){
            depHeadStaff.add(departmentHeads.get(i).getStaff());
        }
        for (int i=0; i<deans.size(); i++){
            depHeadStaff.add(deans.get(i).getStaff());
        }
        for (int i=0; i<staffs.size(); i++) {
            if(depHeadStaff.contains(staffs.get(i)) || staffs.get(i).getDepartment().getId() != department.getId()){
                staffs.remove(staffs.get(i));
                i--;        //because when item remove the structure of list is changed. so we have to move back at every remove!
            }
        }
        return staffs;
    }

    @RequestMapping(value = "/{id}/editDepHead")
    public String editDepHead(@PathVariable int id, Model model){
        DepartmentHead departmentHead = depHeadRepository.findById(id);
        model.addAttribute("depHead", departmentHead);
        Department department = departmentHead.getDepartment();
        model.addAttribute("department", department);
        List<Staff> staffs = getNonDepHeadStaffs(department);
        staffs.add(departmentHead.getStaff());
        model.addAttribute("staffs", staffs);

        model.addAttribute("isEdit", true);
        return "admin/editDepHead";
    }

    @PostMapping(value = {"/depHeads/depHead", "/depHeads/depHead/{id}"})
    public String addDepartment(@Valid DepartmentHead departmentHead, BindingResult bindingResult, Model model){
        if(departmentHead.getStaff().getDepartment().getId() != departmentHead.getDepartment().getId()){
            List<Department> departments = getNonDepHeadDepartments();
            List<Staff> staffs = getNonDepHeadStaffs();

            model.addAttribute("departments", departments);
            model.addAttribute("staffs", staffs);
            model.addAttribute("depHead", new DepartmentHead());
            model.addAttribute("isEdit", false);

            model.addAttribute("staff", departmentHead.getStaff());
            model.addAttribute("department", departmentHead.getDepartment());

            model.addAttribute("cannotDepHead", true);

            return "admin/editDepHead";
        }

        if(departmentHead.getId() != 0){
            DepartmentHead departmentHead1 = depHeadRepository.findById(departmentHead.getId());

            Users user = usersRepository.findByStaff(departmentHead1.getStaff());
            user.getRoles().remove(roleRepository.findByRole("DEPARTMENT"));

            if(user.getRoles().isEmpty()){
                usersRepository.delete(user);
            }
        }

        if(usersRepository.findByStaff(departmentHead.getStaff()) == null){
            Users user = new Users(1, departmentHead.getStaff().getUserName(), departmentHead.getStaff().getPassword(), departmentHead.getStaff());
            user.setRole(roleRepository.findByRole("DEPARTMENT"));
            user.setHeadDepartmentId(departmentHead.getDepartment());
            usersRepository.save(user);
        } else if(usersRepository.findByStaff(departmentHead.getStaff()).getStaff() == departmentHead.getStaff()){
            Users users = usersRepository.findByStaff(departmentHead.getStaff());
            users.setRole(roleRepository.findByRole("DEPARTMENT"));
            users.setHeadDepartmentId(departmentHead.getDepartment());
        }


        depHeadRepository.save(departmentHead);
        return "redirect:/admin/depHeads";
    }

    @RequestMapping(value = "/{id}/deleteDepHead")
    public String deleteDepHead(@PathVariable int id) {

        DepartmentHead departmentHead = depHeadRepository.findById(id);

        Users user = usersRepository.findByStaff(departmentHead.getStaff());
        user.getRoles().remove(roleRepository.findByRole("DEPARTMENT"));
        user.setHeadDepartmentId(null);

        if(user.getRoles().isEmpty()){
            usersRepository.delete(user);
        }

        depHeadRepository.deleteById(id);
        return "redirect:/admin/depHeads";
    }
}
