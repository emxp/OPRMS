package com.example.new1.Model.Security;

import com.example.new1.Model.Academic.*;
import com.example.new1.Model.Security.Role;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Entity
public class Users {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String password;
    private String userName;
    private int active;

    private int adminId = 0;


    @OneToOne
    @JoinColumn(name = "oneToFive_id", referencedColumnName = "id")
    private OneToFiveGroup oneToFiveId = null;

    @OneToOne
    @JoinColumn(name = "development_id", referencedColumnName = "id")
    private DevelopmentGroup developmentId = null;

    private int coordinatorId = 0;

    @OneToOne
    @JoinColumn(name = "dean_id", referencedColumnName = "id")
    private College deanId = null;


    @OneToOne
    @JoinColumn(name = "headDepartment_id", referencedColumnName = "id")
    private Department headDepartmentId = null;       //if the staff is a department head, then this will not be 0;

    @OneToOne
    @JoinColumn(name = "staff_id", referencedColumnName = "id")
    private Staff staff;

    @ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinTable(name="user_role",joinColumns = @JoinColumn(name="id"),inverseJoinColumns = @JoinColumn(name="role_id"))
    private List<Role> roles = new ArrayList<>();

    public Users() {
    }

    public Users(Users users) {
        this.active = users.getActive();
        this.roles = users.getRoles();
        this.userName = users.getUserName();
        this.id = users.getId();
        this.password = users.getPassword();
    }

    public Users(int active, String userName, String password , Staff staff) {
        this.password = password;
        this.userName = userName;
        this.active = active;
        this.staff = staff;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Staff getStaff() {
        return staff;
    }

    public void setStaff(Staff staff) {
        this.staff = staff;
    }

    public int getActive() {
        return active;
    }

    public void setActive(int active) {
        this.active = active;
    }

    public List<Role> getRoles() {
        return roles;
    }

    public void setRoles(List<Role> roles) {
        this.roles = roles;
    }

    public boolean isAdmin() {
        return (adminId != 0);
    }

    public boolean isInOneToFive() {        //returns if the user is a 125 leader
        return (oneToFiveId != null);
    }

    public boolean isInDevelopment() {          //returns if the user is a dev leader
        return (developmentId != null);
    }

    public boolean isInCoordinator() {
        return (coordinatorId != 0);
    }

    public boolean isDepartmentHead() {         //returns if the user is a dep leader
        return (headDepartmentId != null);
    }

    public boolean isDean() {
        return (deanId != null);
    }

    public boolean isLeader() {
        return (deanId != null || headDepartmentId !=null || oneToFiveId !=null || developmentId != null);
    }

    public int getAdminId() {
        return adminId;
    }

    public void setAdminId(int adminId) {
        this.adminId = adminId;
    }

    public OneToFiveGroup getOneToFiveId() {
        return oneToFiveId;
    }

    public void setOneToFiveId(OneToFiveGroup oneToFiveId) {
        this.oneToFiveId = oneToFiveId;
    }

    public DevelopmentGroup getDevelopmentId() {
        return developmentId;
    }

    public void setDevelopmentId(DevelopmentGroup developmentId) {
        this.developmentId = developmentId;
    }

    public int getCoordinatorId() {
        return coordinatorId;
    }

    public void setCoordinatorId(int coordinatorId) {
        this.coordinatorId = coordinatorId;
    }

    public College getDeanId() {
        return deanId;
    }

    public void setDeanId(College deanId) {
        this.deanId = deanId;
    }

    public Department getHeadDepartmentId() {
        return headDepartmentId;
    }

    public void setHeadDepartmentId(Department headDepartmentId) {
        this.headDepartmentId = headDepartmentId;
    }

    public void setRole(Role role) {
        this.roles.add(role);
    }

    public String userFormalName(){
        return staff.getFormalName();
    }

    public String userFullName(){
        return staff.getFullName();
    }

    public Integer retAllNewPlans() {

        Integer allNewPlans = 0;

        if (isInDevelopment()) {
            allNewPlans += getDevelopmentId().getNewPlans();
        }
        if (isDepartmentHead()) {
            allNewPlans += getHeadDepartmentId().getNewPlans();
        }
        if (isDean()) {
            allNewPlans += getDeanId().getNewPlans();
        }

        return allNewPlans;
    }

    public Integer retAllNewPlanByDev() {
        if (isInDevelopment()) {
             return getDevelopmentId().getNewPlans();
        } else {
            return null;
        }
    }
    public Integer retAllNewPlanByDepartment() {
        if (isDepartmentHead()) {
            return getHeadDepartmentId().getNewPlans();
        } else {
            return null;
        }
    }
    public Integer retAllNewPlanByCollege() {
        if (isDean()) {
            return getDeanId().getNewPlans();
        } else {
            return null;
        }
    }

    public Integer retAllNewReports() {

        Integer allNewReports = 0;

        if (isInDevelopment()) {
            allNewReports += getDevelopmentId().getNewReports();
        }
        if (isDepartmentHead()) {
            allNewReports += getHeadDepartmentId().getNewReports();
        }
        if (isDean()) {
            allNewReports += getDeanId().getNewReports();
        }

        return allNewReports;
    }

    public Integer retAllNewReportByDev() {
        if (isInDevelopment()) {
            return getDevelopmentId().getNewReports();
        } else {
            return null;
        }
    }
    public Integer retAllNewReportByDepartment() {
        if (isDepartmentHead()) {
            return getHeadDepartmentId().getNewReports();
        } else {
            return null;
        }
    }
    public Integer retAllNewReportByCollege() {
        if (isDean()) {
            return getDeanId().getNewReports();
        } else {
            return null;
        }
    }

}
