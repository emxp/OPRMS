package com.example.new1.Model.Administration;

import com.example.new1.Model.Academic.Department;
import com.example.new1.Model.Academic.Staff;

import javax.persistence.*;

@Entity
public class Director {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    @OneToOne
    @JoinColumn(name = "adminStaff_id", referencedColumnName = "id")
    private AdminStaff adminStaff;
    @OneToOne
    @JoinColumn(name = "directorate_id", referencedColumnName = "id")
    private Directorate directorate;

    public Director() {
    }

    public Director(AdminStaff adminStaff, Directorate directorate) {
        this.adminStaff = adminStaff;
        this.directorate = directorate;
    }

    public int getId() {
        return id;
    }

    public AdminStaff getAdminStaff() {
        return adminStaff;
    }

    public void setAdminStaff(AdminStaff adminStaff) {
        this.adminStaff = adminStaff;
    }

    public Directorate getDirectorate() {
        return directorate;
    }

    public void setDirectorate(Directorate directorate) {
        this.directorate = directorate;
    }
}
