package com.example.new1.Controller.staff;

import com.example.new1.Model.Academic.Department;
import com.example.new1.Model.Academic.Staff;
import com.example.new1.Model.Security.Users;
import com.example.new1.Repository.*;
import com.example.new1.Repository.Security.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping(value = "/staff")
@PreAuthorize("hasAnyRole('DEPARTMENT')")
public class depHeadStaffController {

    @Autowired
    private StaffRepository staffRepository;
    @Autowired
    private DepartmentRepository departmentRepository;
    @Autowired
    private DeanRepository deanRepository;
    @Autowired
    private DepHeadRepository depHeadRepository;
    @Autowired
    private CoordinatorRepository coordinatorRepository;
    @Autowired
    private OneToFiveRepository oneToFiveRepository;
    @Autowired
    private DevelopmentRepository developmentRepository;

    @Autowired
    private UsersRepository usersRepository;

    public Users getUser(){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return usersRepository.findUsersByUserName(auth.getName());
    }

    public List<Staff> getAllStaffs(){
        return staffRepository.findByDepartment_Id(getUser().getHeadDepartmentId().getId());
    }

    public List<Department> getDepartment(){
        List<Department> departments = new ArrayList<>();
        departments.add(departmentRepository.findById(getUser().getHeadDepartmentId().getId()));
        return departments;
    }

    @RequestMapping("/staffs")
    public String listStaff(ModelMap modelMap) {
        modelMap.put("staffs", getAllStaffs());
        modelMap.put("user", getUser());
        return "staff/staffInfo";
    }

    @RequestMapping(value = "/{id}/editStaff", params = "edit=true")
    public String editStaff(@PathVariable int id, Model model){
        Staff staff = staffRepository.findById(id);
        model.addAttribute("departments", getDepartment());
        model.addAttribute("staff", staff);
        model.addAttribute("isEdit", true);
        model.addAttribute("user", getUser());
        return "staff/editStaff";
    }
    @RequestMapping(value = "/addStaff")
    public String newStaff(ModelMap modelMap){
        modelMap.put("departments", getDepartment());
        modelMap.put("staff", new Staff());
        modelMap.put("isEdit", false);
        modelMap.put("user", getUser());
        return "staff/editStaff";
    }

    @PostMapping(value = {"/staffs/staff", "/staffs/staff/{id}"})
    public String addStaff(@Valid Staff staff, BindingResult bindingResult, Model model){
        if (bindingResult.hasErrors()) {
            model.addAttribute("departments", getDepartment());
            if(staff.getId() == 0){
                model.addAttribute("isEdit", false);
            }else{
                model.addAttribute("isEdit", true);
            }

            model.addAttribute("user", getUser());
            return "staff/editStaff";
        }
        if(staff.getId() == 0){
            staffRepository.save(staff);
            Staff staff1 = staffRepository.findById(staff.getId());
            staff1.setUniId("aastu"+staff1.getId());
            staff1.setUserName("aastu"+staff1.getId());
            staff1.setPassword("aastu"+staff1.getId());
            staffRepository.save(staff1);
        }
        staffRepository.save(staff);
        return "redirect:/staff/staffs";
    }

    @RequestMapping(value = "/{id}/deleteStaff")
    public String deleteStaff(@PathVariable int id, Model model){
        if(deanRepository.findByStaff_Id(id).isEmpty()
                && depHeadRepository.findByStaff_Id(id).isEmpty()
                && coordinatorRepository.findByStaff_Id(id).isEmpty()
                && oneToFiveRepository.findByLeader_Id(id).isEmpty()
                && developmentRepository.findByLeader_Id(id).isEmpty()){
            staffRepository.deleteById(id);
            return "redirect:/staff/staffs";
        }else {
            Staff staff= staffRepository.findById(id);
            model.addAttribute("staffs", getAllStaffs());
            model.addAttribute("deletedStaff", staff);
            model.addAttribute("canNotDelete", true);
            model.addAttribute("user", getUser());
            return "staff/staffInfo";
        }
    }
}
