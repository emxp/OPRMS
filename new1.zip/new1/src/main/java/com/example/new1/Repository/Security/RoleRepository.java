package com.example.new1.Repository.Security;

import com.example.new1.Model.Security.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Integer> {

    Role findById(int id);
    Role findByRole(String role);
}
