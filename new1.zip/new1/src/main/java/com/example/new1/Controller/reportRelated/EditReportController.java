package com.example.new1.Controller.reportRelated;

import com.example.new1.Repository.reportRepositories.Report1JpaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.example.new1.Model.Security.Users;
import com.example.new1.Model.planRelated.*;
import com.example.new1.Model.reportRelated.*;
import com.example.new1.Repository.Security.UsersRepository;
import com.example.new1.Repository.general.ScrollRepository;
import com.example.new1.Repository.planRepositories.PlanJpaRepository;
import com.example.new1.Repository.reportRepositories.ReportJpaRepository;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@Controller
@PreAuthorize("hasAnyRole('ONE_TO_FIVE', 'DEVELOPMENT', 'DEPARTMENT', 'DEAN')")
public class EditReportController {

    @Autowired
    ReportJpaRepository reportJpaRepository;

    @Autowired
    Report1JpaRepository report1JpaRepository;

    @Autowired
    PlanJpaRepository planJpaRepository;

    @Autowired
    ScrollRepository scrollRepository;

    @Autowired
    UsersRepository usersRepository;

    List<String> whichOneIsClicked = new ArrayList<>();

    private Users getUsers() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return usersRepository.findUsersByUserName(auth.getName());
    }

    @RequestMapping({"/editReport", "/addReportEditRow"})
    public String editAPlan(Report report, BindingResult bindingResult, ModelMap modelMap) {

        modelMap.put("user", getUsers());
        return "editReport";
    }

    @RequestMapping(value = "/addReportEditRow", params = {"saveAllEditedData"}, method = RequestMethod.POST)
    public String saveAllPlans(@Valid Report report, BindingResult bindingResult, HttpServletRequest request, ModelMap modelMap) {
        if (bindingResult.hasErrors()){
            System.out.println("ytttttttttttttttttttt");
            Integer planId = Integer.parseInt(request.getParameter("saveAllEditedData"));
//            report = reportJpaRepository.getOne(planId);
            whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();

            Plan plan = planJpaRepository.getOne(planId);
            report.setPlan(plan);
            report.setPlanId(plan.getId());

            modelMap.put("report", report);
            modelMap.put("whichOneIsClicked", whichOneIsClicked);

            modelMap.put("user", getUsers());
            return "editReport";
        }

        reportJpaRepository.save(report);

        return "redirect:/reportsList";
    }

    @RequestMapping(value = "/editReport/{id}")
    public String editASinglePlan(Report report, BindingResult bindingResult, @PathVariable int id, ModelMap modelMap) {

        whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();
        report = reportJpaRepository.getOne(id);

//        report.setPlan(plan);
//        report.setPlanId(id);

        modelMap.put("report", report);
        modelMap.put("whichOneIsClicked", whichOneIsClicked);

        modelMap.put("user", getUsers());
        return "editReport";
    }

}
