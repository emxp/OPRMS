package com.example.new1.Controller.planRelated;


import com.example.new1.Model.Academic.OneToFiveGroup;
import com.example.new1.Repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import com.example.new1.Model.planRelated.*;
import com.example.new1.Model.reportRelated.*;
import com.example.new1.Repository.general.ScrollRepository;
import com.example.new1.Repository.planRepositories.*;
import com.example.new1.Repository.reportRepositories.*;
import com.example.new1.Repository.Security.RoleRepository;
import com.example.new1.Repository.Security.UsersRepository;
import com.example.new1.Model.Academic.Dean;
import com.example.new1.Model.Security.Users;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

@Controller
@PreAuthorize("hasAnyRole('ONE_TO_FIVE', 'COORDINATOR' , 'DEVELOPMENT', 'DEPARTMENT', 'DEAN')")
public class PlansListController {

    @Autowired
    PlanPagingRepository planPagingRepository;

    @Autowired
    PlanJpaRepository planJpaRepository;

    @Autowired
    ReportJpaRepository reportJpaRepository;

    @Autowired
    ScrollRepository scrollRepository;

    @Autowired
    UsersRepository usersRepository;

    @Autowired
    OneToFiveRepository oneToFiveRepository;

    @Autowired
    DevelopmentRepository developmentGroupRepository;

    @Autowired
    DepartmentRepository departmentRepository;

    @Autowired
    CollegeRepository collegeRepository;

    @Autowired
    RoleRepository roleRepository;

    @Autowired
    DeanRepository deanRepository;

    List<String> whichOneIsClicked = new ArrayList<>();

    private Users getUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return usersRepository.findUsersByUserName(auth.getName());
    }

    @RequestMapping("/plansList")
    public String showPlansList(ModelMap modelMap, @RequestParam(defaultValue = "1") int pageOneToFiveSent, @RequestParam(defaultValue = "1") int pageDevSent, @RequestParam(defaultValue = "1") int pageDevReceived, @RequestParam(defaultValue = "1") int pageDepHeadSent, @RequestParam(defaultValue = "1") int pageDepHeadReceived, @RequestParam(defaultValue = "1") int pageDeanSent, @RequestParam(defaultValue = "1") int pageDeanReceived) {
        whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();

        Users user = getUser();

        if (user.isDean()) {
            Dean dean = deanRepository.findByStaff(user.getStaff());

            modelMap.put("allSentPlansByDean", planPagingRepository.findBySenderGroupId(user.getDeanId().getId(), PageRequest.of(pageDeanSent - 1, 6, Sort.Direction.DESC, "id")));
            modelMap.put("allReceivedPlansByDean", planPagingRepository.findByReceiverGroupId(user.getDeanId().getId(), PageRequest.of(pageDeanReceived - 1, 6, Sort.Direction.DESC, "id")));
            modelMap.put("college", dean.getCollege());
        }else if (user.isDepartmentHead()) {
            modelMap.put("allSentPlansByDepartment", planPagingRepository.findBySenderGroupId(user.getStaff().getDepartment().getId(), PageRequest.of(pageDepHeadSent - 1, 6, Sort.Direction.DESC, "id")));
            modelMap.put("allReceivedPlansByDepartment", planPagingRepository.findByReceiverGroupId(user.getStaff().getDepartment().getId(), PageRequest.of(pageDepHeadReceived - 1, 6, Sort.Direction.DESC, "id")));
            modelMap.put("department", user.getStaff().getDepartment());
        }
        if (user.isInDevelopment()) {
            modelMap.put("allSentPlansByOneToFive", planPagingRepository.findBySenderGroupId(user.getOneToFiveId().getId(), PageRequest.of(pageOneToFiveSent - 1, 6, Sort.Direction.DESC, "id")));
            modelMap.put("allSentPlansByDevelopment", planPagingRepository.findBySenderGroupId(user.getDevelopmentId().getId(), PageRequest.of(pageDevSent - 1, 6, Sort.Direction.DESC, "id")));
            modelMap.put("allReceivedPlansByDevelopment", planPagingRepository.findByReceiverGroupId(user.getDevelopmentId().getId(), PageRequest.of(pageDevReceived - 1, 6, Sort.Direction.DESC, "id")));
            modelMap.put("oneToFive", oneToFiveRepository.getOne(user.getOneToFiveId().getId()));
            modelMap.put("development", developmentGroupRepository.getOne(user.getDevelopmentId().getId()));
        }
        else if (user.isInOneToFive()) {
            modelMap.put("allSentPlansByOneToFive", planPagingRepository.findBySenderGroupId( user.getOneToFiveId().getId(), PageRequest.of(pageOneToFiveSent - 1, 6, Sort.Direction.DESC, "id")));
            OneToFiveGroup oneToFiveGroup  = oneToFiveRepository.getOne(user.getOneToFiveId().getId());
            modelMap.put("oneToFive", oneToFiveGroup);
        }

        whichOneIsClicked = scrollRepository.setTheClickedValue(pageOneToFiveSent, pageDevSent, pageDevReceived, pageDepHeadSent, pageDepHeadReceived, pageDeanSent, pageDeanReceived);

        modelMap.put("user", getUser());
        modelMap.put("currentPageOneToFiveSent", pageOneToFiveSent);
        modelMap.put("currentPageDevSent", pageDevSent);
        modelMap.put("currentPageDevReceived", pageDevReceived);
        modelMap.put("currentPageDepHeadSent", pageDepHeadSent);
        modelMap.put("currentPageDepHeadReceived", pageDepHeadReceived);
        modelMap.put("currentPageDeanSent", pageDeanSent);
        modelMap.put("currentPageDeanReceived", pageDeanReceived);

        modelMap.put("whichOneIsClicked", whichOneIsClicked);

        return "plansList";
    }

    @RequestMapping(value = "/plansList", params = {"kifet"})
    public String showASinglePlan(ModelMap modelMap, HttpServletRequest request) {
        Integer newRep = Integer.parseInt(request.getParameter("kifet").substring(0, 1));
        Integer id = Integer.parseInt(request.getParameter("kifet").substring(1));

        Plan plan = planJpaRepository.getOne(id.intValue());
        Boolean hasReport = false;


        for (Report report : reportJpaRepository.findAll()) {
            if (report.getPlanId() == plan.getId()){
                hasReport = true;
                break;
            }
        }

        if (!hasReport && (newRep == 1))
            modelMap.put("newRepButton", true);

        if (newRep == 0)
            modelMap.put("newRep", false);
        else if(newRep == 1)
            modelMap.put("newRep", true);

        if (plan.isNewPlan())
            decrementViewedPlans(plan);

        modelMap.put("plan", plan);
        modelMap.put("hasReport", hasReport);
        modelMap.put("user", getUser());

        return "planServer";
    }

    @RequestMapping(value = "/plansList", params = {"atifa"})
    public String deleteASinglePlan(HttpServletRequest request) {

        Integer id = Integer.parseInt(request.getParameter("atifa"));
        Plan plan = planJpaRepository.getOne(id.intValue());

        //delete the report first;
        for (Report report : reportJpaRepository.findAll()) {
            if(report.getPlanId() == id.intValue()) {
                reportJpaRepository.delete(report);
                break;
            }
        }

        if (plan.isNewPlan())
            decrementViewedPlans(plan);

        //then delete the report;
        planJpaRepository.deleteById(id.intValue());

        return "redirect:/plansList";
    }

    @RequestMapping(value = "/plansList", params = {"astekakil"})
    public String editASinglePlan(Plan plan, BindingResult bindingResult, HttpServletRequest request, ModelMap modelMap) {
        whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();
        Integer id = Integer.parseInt(request.getParameter("astekakil"));

        plan = planJpaRepository.getOne(id.intValue());

        modelMap.put("plan", plan);
        modelMap.put("whichOneIsClicked", whichOneIsClicked);

        modelMap.put("user", getUser());
        return "editPlan";
    }


    @RequestMapping(value = "/plansList", params = {"addisPlan"})
    public String showNewPlan(Plan plan, BindingResult bindingResult, HttpServletRequest request, ModelMap modelMap) {

        int dotPosition = request.getParameter("addisPlan").indexOf('.');
        int senderId = Integer.parseInt(request.getParameter("addisPlan").substring(0, dotPosition));
        int receiverId = Integer.parseInt(request.getParameter("addisPlan").substring(dotPosition + 1));

        plan.setSenderGroupId(senderId);
        plan.setReceiverGroupId(receiverId);

        whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();
        modelMap.put("whichOneIsClicked", whichOneIsClicked);

        modelMap.put("user", getUser());
        return "planServerNewTwo";
    }

    public void decrementViewedPlans(Plan plan) {
        if (plan.isNewPlan()) {         //When a sender clicks the plan he get into this if clause, but can not do any thing;
            if (getUser().isInDevelopment() && (getUser().getDevelopmentId().getId() == plan.getReceiverGroupId())) {          //if the user(receiver) is a development leader;
                if (getUser().getDevelopmentId().getNewPlans() > 0) {
                    getUser().getDevelopmentId().decrementNewPlans();
                    developmentGroupRepository.save(getUser().getDevelopmentId());
                    plan.setNewPlan(false);
                    planJpaRepository.save(plan);
                }
            }
            if (getUser().isDepartmentHead() && (getUser().getHeadDepartmentId().getId() == plan.getReceiverGroupId())) {     //if the user(receiver) is department head;
                if (getUser().getHeadDepartmentId().getNewPlans() > 0) {
                    getUser().getHeadDepartmentId().decrementNewPlans();
                    departmentRepository.save(getUser().getHeadDepartmentId());
                    plan.setNewPlan(false);
                    planJpaRepository.save(plan);
                }
            }
            if (getUser().isDean() && (getUser().getDeanId().getId() == plan.getReceiverGroupId())) {
                if (getUser().getDeanId().getNewPlans() > 0) {
                    getUser().getDeanId().decrementNewPlans();
                    collegeRepository.save(getUser().getDeanId());
                    plan.setNewPlan(false);
                    planJpaRepository.save(plan);
                }
            }
        }
    }
}
