package com.example.new1.Model.Academic;

import org.hibernate.validator.constraints.Length;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import java.util.ArrayList;
import java.util.List;

@Entity
public class OneToFiveGroup {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @NotEmpty(message = "መሞላት ያለበት መረጃ！")
    @Length(max = 45, message = "በዚህ መረጃ ላይ ከ45 ፊደሎች በላይ አይሞሉም！")
    @Pattern(regexp = "[A-z 0-9 /s]*", message = "በዚህ መረጃ ላይ የEnglish ፊደሎች እና ቁጥሮች ብቻ ይሞላሉ！")
    private String groupName;

    @OneToOne
    @JoinColumn(name = "leader_id", referencedColumnName = "id")
    private Staff leader;

    @OneToOne
    @JoinColumn(name = "department_id", referencedColumnName = "id")
    private Department department;

    @OneToOne
    @JoinColumn(name = "developmentGroup_id", referencedColumnName = "id")
    private DevelopmentGroup developmentGroup;

    @ManyToMany
    @JoinTable(name="OneToFiveMembers",joinColumns = @JoinColumn(name="id"),inverseJoinColumns = @JoinColumn(name="staff_id"))
    private List<Staff> oneToFiveMembers = new ArrayList<>();

    public OneToFiveGroup() {
    }

    public OneToFiveGroup(String groupName, Staff leader, Department department, DevelopmentGroup developmentGroup, List<Staff> oneToFiveMembers) {
        this.groupName = groupName;
        this.leader = leader;
        this.department = department;
        this.developmentGroup = developmentGroup;
        this.oneToFiveMembers = oneToFiveMembers;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public Staff getLeader() {
        return leader;
    }

    public void setLeader(Staff leader) {
        this.leader = leader;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public DevelopmentGroup getDevelopmentGroup() {
        return developmentGroup;
    }

    public void setDevelopmentGroup(DevelopmentGroup developmentGroup) {
        this.developmentGroup = developmentGroup;
    }

    public List<Staff> getOneToFiveMembers() {
        return oneToFiveMembers;
    }

    public void setOneToFiveMembers(List<Staff> oneToFiveMembers) {
        this.oneToFiveMembers = oneToFiveMembers;
    }
}
