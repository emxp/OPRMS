package com.example.new1.Controller.Security;

import com.example.new1.Model.Security.Role;
import com.example.new1.Model.Security.Users;
import com.example.new1.Repository.Security.RoleRepository;
import com.example.new1.Repository.Security.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class loginController {

    @Autowired
    private UsersRepository usersRepository;

    @Autowired
    private RoleRepository roleRepository;

    @RequestMapping(value = "/" ,method = RequestMethod.GET)
    public String home(){
        return "login";
    }

    @RequestMapping(value = "/login" ,method = RequestMethod.GET)
    public ModelAndView login(){
        Users users=new Users();
        ModelAndView modelAndView=new ModelAndView();
        modelAndView.addObject("users",users);
        modelAndView.setViewName("login");

        return modelAndView;
    }

    @RequestMapping(value = "/login" ,params = {"Error"})
    public ModelAndView showLoginErrors(){
        Users users=new Users();
        ModelAndView modelAndView=new ModelAndView();
        modelAndView.addObject("users",users);
        modelAndView.addObject("errorz", true);


        modelAndView.setViewName("login");
        return modelAndView;
    }

    @RequestMapping(value = "/loginProcessor" ,method = RequestMethod.POST)
    public String loginProcessor(){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        Users user=usersRepository.findUsersByUserName(auth.getName());
        Role roles = roleRepository.findByRole("ADMIN");

        if(user.isAdmin()){
            return "redirect:/admin/staffs";
        }else if(user.isInCoordinator()){
            return "redirect:/staff/coordinator";
        }else{
            return "redirect:/staff/coordination";
        }
    }
}
