package com.example.new1.Repository;

import com.example.new1.Model.Administration.AdminStaff;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminStaffRepository extends JpaRepository<AdminStaff, Integer> {
}
