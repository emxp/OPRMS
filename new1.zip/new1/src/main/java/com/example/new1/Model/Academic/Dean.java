package com.example.new1.Model.Academic;

import javax.persistence.*;

@Entity
public class Dean {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    @OneToOne
    @JoinColumn(name = "staff_id", referencedColumnName = "id")
    private Staff staff;
    @OneToOne
    @JoinColumn(name = "college_id", referencedColumnName = "id")
    private College college;

    public Dean() {
    }

    public Dean(Staff staff, College college) {
        this.staff = staff;
        this.college = college;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Staff getStaff() {
        return staff;
    }

    public void setStaff(Staff staff) {
        this.staff = staff;
    }

    public College getCollege() {
        return college;
    }

    public void setCollege(College college) {
        this.college = college;
    }
}
