package com.example.new1.Repository.planRepositories;

import com.example.new1.Model.planRelated.Plan4;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

@Component
public interface Plan4JpaRepository extends JpaRepository<Plan4, Integer> {
}
