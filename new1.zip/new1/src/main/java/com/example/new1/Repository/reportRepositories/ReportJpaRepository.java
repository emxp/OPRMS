package com.example.new1.Repository.reportRepositories;

import com.example.new1.Model.reportRelated.Report;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface ReportJpaRepository extends JpaRepository<Report, Integer> {

//    List<Report> findBySenderGroupId(int senderGroupId);
//    List<Report> findByReceiverGroupId(int receiverGroupId);
    Report findByPlanId(int planId);

}
