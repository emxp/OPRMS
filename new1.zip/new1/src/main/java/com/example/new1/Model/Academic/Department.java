package com.example.new1.Model.Academic;

import org.hibernate.validator.constraints.Length;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;


@Entity
public class Department {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @NotEmpty(message = "መሞላት ያለበት መረጃ！")
    @Length(max = 100, message = "በዚህ መረጃ ላይ ከ100 ፊደሎች በላይ አይሞሉም！")
    @Pattern(regexp = "[A-z /s]*", message = "በዚህ መረጃ ላይ የEnglish ፊደሎች ብቻ ይሞላሉ！")
    private String dep_Name;
    @ManyToOne
    @JoinColumn(name = "college_id", referencedColumnName = "id")
    private College college;

    private Integer newPlans = 0;
    private Integer newReports = 0;

    public Department() {
    }

    public Department(String dep_Name, College college) {
        this.dep_Name = dep_Name;
        this.college = college;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDep_Name() {
        return dep_Name;
    }

    public void setDep_Name(String dep_Name) {
        this.dep_Name = dep_Name;
    }

    public College getCollege() {
        return college;
    }

    public void setCollege(College college) {
        this.college = college;
    }

    public Integer getNewPlans() {
        return newPlans;
    }

    public void setNewPlans(Integer newPlans) {
        this.newPlans = newPlans;
    }

    public Integer getNewReports() {
        return newReports;
    }

    public void setNewReports(Integer newReports) {
        this.newReports = newReports;
    }

    public void incrementNewPlans() {
        setNewPlans(getNewPlans() + 1);
    }

    public void decrementNewPlans() {
        setNewPlans(getNewPlans() - 1);
    }

    public void incrementNewReports() {
        setNewReports(getNewReports() + 1);
    }

    public void decrementNewReports() {
        setNewReports(getNewReports() - 1);
    }
}
