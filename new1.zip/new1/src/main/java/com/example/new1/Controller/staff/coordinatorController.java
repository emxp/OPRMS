package com.example.new1.Controller.staff;

import com.example.new1.Model.Academic.DevelopmentGroup;
import com.example.new1.Model.Academic.OneToFiveGroup;
import com.example.new1.Model.Security.Users;
import com.example.new1.Repository.DevelopmentRepository;
import com.example.new1.Repository.OneToFiveRepository;
import com.example.new1.Repository.Security.UsersRepository;
import com.example.new1.Repository.StaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping(value = "/staff")
@PreAuthorize("hasAnyRole('COORDINATOR')")
public class coordinatorController {

    @Autowired
    private StaffRepository staffRepository;

    @Autowired
    private OneToFiveRepository oneToFiveRepository;

    @Autowired
    private DevelopmentRepository developmentRepository;

    @Autowired
    private UsersRepository usersRepository;

    @RequestMapping(value = "/coordinator")
    public String showCoordination(Model model){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        Users user=usersRepository.findUsersByUserName(auth.getName());

        List<OneToFiveGroup> oneToFiveGroups = oneToFiveRepository.findByDepartment_Id(user.getStaff().getDepartment().getId());
        List<DevelopmentGroup> developmentGroups = developmentRepository.findByDepartment_Id(user.getStaff().getDepartment().getId());

        model.addAttribute("oneToFiveGroups", oneToFiveGroups);
        model.addAttribute("developmentGroups", developmentGroups);

        if(oneToFiveGroups.isEmpty()){
            model.addAttribute("empty1to5", true);
        }

        if(developmentGroups.isEmpty() && !oneToFiveGroups.isEmpty()){
            model.addAttribute("emptyDev", true);
        }

        model.addAttribute("user", user);
        return "staff/staffCoordinator";
    }
}
