package com.example.new1.Controller.staff;

import com.example.new1.Model.Academic.Department;
import com.example.new1.Model.Academic.DevelopmentGroup;
import com.example.new1.Model.Academic.OneToFiveGroup;
import com.example.new1.Model.Academic.Staff;
import com.example.new1.Model.Security.Users;
import com.example.new1.Repository.DevelopmentRepository;
import com.example.new1.Repository.OneToFiveRepository;
import com.example.new1.Repository.Security.RoleRepository;
import com.example.new1.Repository.Security.UsersRepository;
import com.example.new1.Repository.StaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping(value = "/staff")
@PreAuthorize("hasAnyRole('COORDINATOR')")
public class developmentController {

    @Autowired
    private StaffRepository staffRepository;
    @Autowired
    private OneToFiveRepository oneToFiveRepository;
    @Autowired
    private DevelopmentRepository developmentRepository;
    @Autowired
    private UsersRepository usersRepository;
    @Autowired
    private RoleRepository roleRepository;

    static DevelopmentGroup tempDevelopmentGroup = new DevelopmentGroup();

    public Users getUser(){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return usersRepository.findUsersByUserName(auth.getName());
    }


    public List<OneToFiveGroup> groupLessOneToFiveGroups(){
        Users user= getUser();

        List<OneToFiveGroup> oneToFiveGroupList = oneToFiveRepository.findByDepartment_Id(user.getStaff().getDepartment().getId());
        List<OneToFiveGroup> oneToFiveGroups = new ArrayList<>();
        List<DevelopmentGroup> developmentGroups = developmentRepository.findAll();
        oneToFiveGroups.clear();

        if(developmentGroups.isEmpty()){
            return oneToFiveGroupList;
        }else {
            for (int i = 0; i < developmentGroups.size(); i++) {
                oneToFiveGroups.addAll(developmentGroups.get(i).getDevelopmentMembers());
            }

            for (int j = 0; j < oneToFiveGroupList.size(); j++) {
                if(oneToFiveGroups.contains(oneToFiveGroupList.get(j))){
                    oneToFiveGroupList.remove(j);
                    j--;
                }
            }
        }
        return oneToFiveGroupList;
    }

    @RequestMapping(value = "/addNewDevelopment")
    public String addDevelopment(DevelopmentGroup developmentGroup, Model model ){
        Users user= getUser();

        List<OneToFiveGroup> oneToFiveGroupList = groupLessOneToFiveGroups();
        if(oneToFiveGroupList.isEmpty()){
            model.addAttribute("cannotAddDevelopment", true);
            model.addAttribute("oneToFiveGroups", oneToFiveRepository.findByDepartment_Id(user.getStaff().getDepartment().getId()));
            model.addAttribute("developmentGroups", developmentRepository.findByDepartment_Id(user.getStaff().getDepartment().getId()));

            model.addAttribute("user", user);
            return "staff/staffCoordinator";
        }else {
            developmentGroup.getDevelopmentMembers().add(new OneToFiveGroup());
            model.addAttribute("oneToFiveGroups", groupLessOneToFiveGroups());

            model.addAttribute("user", user);
            return "staff/editDevelopment";
        }
    }

    @RequestMapping(value = {"/addDevelopment", "/addDevelopment/{id}"}, params = "addRow")
    public String addRow(DevelopmentGroup developmentGroup , BindingResult bindingResult, Model model){
        List<OneToFiveGroup> oneToFiveGroups = groupLessOneToFiveGroups();

        if(developmentGroup.getId() == 0){
            model.addAttribute("oneToFiveGroups", oneToFiveGroups);
            model.addAttribute("isEdit", false);
        }else{
            List<OneToFiveGroup> oneToFiveGroupList = new ArrayList<>();
            oneToFiveGroupList.addAll(oneToFiveGroups);
            oneToFiveGroupList.addAll(developmentGroup.getDevelopmentMembers());
            model.addAttribute("oneToFiveGroups", oneToFiveGroupList);
            model.addAttribute("isEdit", true);
        }

        if(developmentGroup.getDevelopmentMembers().size() < 5){
            developmentGroup.getDevelopmentMembers().add(new OneToFiveGroup());
        }

        model.addAttribute("user", getUser());
        return "staff/editDevelopment";
    }

    @RequestMapping(value = {"/addDevelopment", "/addDevelopment/{id}"}, params={"removeRow"})
    public String removeRow(final DevelopmentGroup developmentGroup, final BindingResult bindingResult, final HttpServletRequest req, Model model) {
        if(developmentGroup.getDevelopmentMembers().size() > 1 ){
            final Integer rowId = Integer.valueOf(req.getParameter("removeRow"));
            developmentGroup.getDevelopmentMembers().remove(rowId.intValue());
        }
        List<OneToFiveGroup> oneToFiveGroups = groupLessOneToFiveGroups();

        if(developmentGroup.getId() == 0) {
            model.addAttribute("oneToFiveGroups", oneToFiveGroups);
            model.addAttribute("isEdit", false);
        }else{
            List<OneToFiveGroup> oneToFiveGroupList = new ArrayList<>();
            oneToFiveGroupList.addAll(oneToFiveGroups);
            oneToFiveGroupList.addAll(developmentGroup.getDevelopmentMembers());
            model.addAttribute("oneToFiveGroups", oneToFiveGroupList);
            model.addAttribute("isEdit", true);
        }

        model.addAttribute("user", getUser());
        return "staff/editDevelopment";
    }

    @RequestMapping(value={"/addDevelopment", "/addDevelopment/{id}"})
    public String saveOnetoFive(@Valid DevelopmentGroup developmentGroup, BindingResult bindingResult, ModelMap model) {
        if (bindingResult.hasErrors()) {
            if(developmentGroup.getId() == 0){
                developmentGroup = tempDevelopmentGroup;
                model.addAttribute("isEdit", false);
            }else{
                developmentGroup = developmentRepository.findById(developmentGroup.getId());
                model.addAttribute("isEdit", true);
            }
            List<OneToFiveGroup> oneToFiveGroupList = new ArrayList<>();
            oneToFiveGroupList.addAll(groupLessOneToFiveGroups());
            oneToFiveGroupList.addAll(developmentGroup.getDevelopmentMembers());
            model.addAttribute("oneToFiveGroups", oneToFiveGroupList);

            model.addAttribute("user", getUser());
            return "staff/editDevelopment";
        }

        List<OneToFiveGroup> oneToFiveGroups = developmentGroup.getDevelopmentMembers();
        oneToFiveGroups = oneToFiveGroups.stream().distinct().collect(Collectors.toList());
        developmentGroup.getDevelopmentMembers().clear();
        developmentGroup.getDevelopmentMembers().addAll(oneToFiveGroups);
        model.addAttribute("developmentGroup", developmentGroup);
        model.addAttribute("oneToFiveGroups", oneToFiveGroups);

        tempDevelopmentGroup = developmentGroup;

        model.addAttribute("user", getUser());
        return "staff/developmentLeader";
    }

    public void deletingDuplicateDevelopmentMembership(DevelopmentGroup developmentGroup){
        if(developmentGroup.getId() != 0){
            DevelopmentGroup developmentGroup1 = developmentRepository.findById(developmentGroup.getId());
            List<OneToFiveGroup> allOneToFives = oneToFiveRepository.findByDepartment_Id(developmentGroup1.getDepartment().getId());

            for (int i=0; i<allOneToFives.size(); i++){
                if(allOneToFives.get(i).getDevelopmentGroup() == developmentGroup1){
                    allOneToFives.get(i).setDevelopmentGroup(null);
                }
            }
        }
    }

    @RequestMapping(value={"/addDevelopment/{id}"}, params = "save")
    public String editOnetoFive(@Valid DevelopmentGroup developmentGroup, BindingResult bindingResult, ModelMap model) {
        if (bindingResult.hasErrors()) {
            developmentGroup = developmentRepository.findById(developmentGroup.getId());
            model.addAttribute("isEdit", true);

            List<OneToFiveGroup> oneToFiveGroupList = new ArrayList<>();
            oneToFiveGroupList.addAll(groupLessOneToFiveGroups());
            oneToFiveGroupList.addAll(developmentGroup.getDevelopmentMembers());
            model.addAttribute("oneToFiveGroups", oneToFiveGroupList);

            model.addAttribute("user", getUser());
            return "staff/editDevelopment";
        }

        if(developmentGroup.getDevelopmentMembers().contains(developmentGroup.getLeader())){
            List<OneToFiveGroup> oneToFiveGroups = developmentGroup.getDevelopmentMembers();
            oneToFiveGroups = oneToFiveGroups.stream().distinct().collect(Collectors.toList());
            developmentGroup.getDevelopmentMembers().clear();
            developmentGroup.getDevelopmentMembers().addAll(oneToFiveGroups);
            Users user= getUser();
            developmentGroup.setDepartment(user.getStaff().getDepartment());

            deletingDuplicateDevelopmentMembership(developmentGroup);

            for (int i=0; i<developmentGroup.getDevelopmentMembers().size(); i++){
                OneToFiveGroup oneToFiveGroup = developmentGroup.getDevelopmentMembers().get(i);
                oneToFiveGroup.setDevelopmentGroup(developmentGroup);
            }

            developmentRepository.save(developmentGroup);
            return "redirect:/staff/coordinator";
        }else {
            List<OneToFiveGroup> oneToFiveGroups = developmentGroup.getDevelopmentMembers();
            oneToFiveGroups = oneToFiveGroups.stream().distinct().collect(Collectors.toList());
            developmentGroup.getDevelopmentMembers().clear();
            developmentGroup.getDevelopmentMembers().addAll(oneToFiveGroups);
            model.addAttribute("developmentGroup", developmentGroup);
            model.addAttribute("oneToFiveGroups", oneToFiveGroups);

            model.addAttribute("user", getUser());
            return "staff/developmentLeader";
        }

    }

    @RequestMapping(value = "/editDevelopment/{id}")
    public String editDevelopment(@PathVariable int id, Model model){
        DevelopmentGroup developmentGroup;
        if(id == 0){
            developmentGroup = tempDevelopmentGroup;
            model.addAttribute("isEdit", false);
        }else{
            developmentGroup = developmentRepository.findById(id);
            model.addAttribute("isEdit", true);
        }
        List<OneToFiveGroup> oneToFiveGroupList = new ArrayList<>();
        oneToFiveGroupList.addAll(groupLessOneToFiveGroups());
        oneToFiveGroupList.addAll(developmentGroup.getDevelopmentMembers());
        model.addAttribute("developmentGroup", developmentGroup);
        model.addAttribute("oneToFiveGroups", oneToFiveGroupList);

        model.addAttribute("user", getUser());
        return "staff/editDevelopment";

    }

    public boolean isDevelopmentMember(DevelopmentGroup developmentGroup){
        List<DevelopmentGroup> developmentGroups = developmentRepository.findAll();
        for (int i=0; i<developmentGroups.size(); i++){
            if(developmentGroups.get(i).getDevelopmentMembers().contains(developmentGroup)){
                return true;
            }
        }
        return false;
    }

    @RequestMapping(value = "/deleteDevelopment/{id}")
    public String deleteDevelopment(@PathVariable int id, Model model){
        Users user= getUser();
        DevelopmentGroup developmentGroup = developmentRepository.findById(id);

        if(isDevelopmentMember(developmentGroup)){
            model.addAttribute("isDevelopmentMember", true);
            model.addAttribute("Development", developmentGroup);
            model.addAttribute("developmentGroups", developmentRepository.findByDepartment_Id(user.getStaff().getDepartment().getId()));
            model.addAttribute("developmentGroups", developmentRepository.findByDepartment_Id(user.getStaff().getDepartment().getId()));

            model.addAttribute("user", getUser());
            return "staff/staffCoordinator";
        }else {

            List<OneToFiveGroup> allOneToFives = oneToFiveRepository.findByDepartment_Id(developmentGroup.getDepartment().getId());

            for (int i=0; i<allOneToFives.size(); i++){
                if(allOneToFives.get(i).getDevelopmentGroup() == developmentGroup){
                    allOneToFives.get(i).setDevelopmentGroup(null);
                }
            }

            Users users = usersRepository.findByStaff(developmentGroup.getLeader().getLeader());
            users.getRoles().remove(roleRepository.findByRole("DEVELOPMENT"));
            users.setDevelopmentId(null);

            if(users.getRoles().isEmpty()){
                usersRepository.delete(users);
            }

            developmentRepository.deleteById(id);
            return "redirect:/staff/coordinator";
        }
    }


    @RequestMapping(value="/makeDevelopmentLeader/{id}")
    public String makeDevelopmentLeader(DevelopmentGroup developmentGroup) {
        Users user= getUser();
        deletingDuplicateDevelopmentMembership(developmentGroup);

        Staff developmentLeader = developmentGroup.getLeader().getLeader();
        developmentGroup.setDepartment(user.getStaff().getDepartment());

        for (int i=0; i<developmentGroup.getDevelopmentMembers().size(); i++){
            developmentGroup.getDevelopmentMembers().get(i).setDevelopmentGroup(developmentGroup);
        }

        deleteDevelopmentLeader(developmentGroup);

        developmentRepository.save(developmentGroup);
        DevelopmentGroup developmentGroup1 = developmentRepository.findById(developmentGroup.getId());
        makeDevelopmentUser(developmentGroup1, developmentLeader);

        return "redirect:/staff/coordinator";
    }

    private void deleteDevelopmentLeader(DevelopmentGroup developmentGroup) {
        if(developmentGroup.getId() != 0){
            DevelopmentGroup developmentGroup1 = developmentRepository.findById(tempDevelopmentGroup.getId());

            Users users = usersRepository.findByStaff(developmentGroup1.getLeader().getLeader());
            users.getRoles().remove(roleRepository.findByRole("DEVELOPMENT"));
            users.setDevelopmentId(null);

            if(users.getRoles().isEmpty()){
                usersRepository.delete(users);
            }
        }
    }

    public void makeDevelopmentUser(DevelopmentGroup developmentGroup, Staff developmentLeader) {

        if(usersRepository.findByStaff(developmentLeader) == null){
            Users users = new Users(1, developmentLeader.getUserName(), developmentLeader.getPassword(), developmentLeader);
            users.setRole(roleRepository.findByRole("DEVELOPMENT"));
            users.setDevelopmentId(developmentGroup);
            usersRepository.save(users);
        } else if(usersRepository.findByStaff(developmentLeader).getStaff() == developmentLeader){
            Users users = usersRepository.findByStaff(developmentLeader);
            users.setRole(roleRepository.findByRole("DEVELOPMENT"));
            users.setDevelopmentId(developmentGroup);
        }
        developmentRepository.save(developmentGroup);
    }
}
