package com.example.new1.Controller.planRelated;

import com.example.new1.Repository.CollegeRepository;
import com.example.new1.Repository.DepartmentRepository;
import com.example.new1.Repository.DevelopmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import com.example.new1.Model.planRelated.*;
import com.example.new1.Model.reportRelated.*;
import com.example.new1.Repository.general.ScrollRepository;
import com.example.new1.Repository.planRepositories.*;
import com.example.new1.Repository.reportRepositories.*;
import com.example.new1.Repository.Security.UsersRepository;
import com.example.new1.Model.Security.Users;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

@Controller
@PreAuthorize("hasAnyRole('ONE_TO_FIVE', 'DEVELOPMENT', 'DEPARTMENT', 'DEAN')")
public class PlanViewerController {

    @Autowired
    PlanJpaRepository planJpaRepository;

    @Autowired
    ReportJpaRepository reportJpaRepository;

    @Autowired
    ScrollRepository scrollRepository;

    @Autowired
    UsersRepository usersRepository;

    List<String> whichOneIsClicked = new ArrayList<>();


    @Autowired
    DevelopmentRepository developmentRepository;

    @Autowired
    DepartmentRepository departmentRepository;
    @Autowired
    CollegeRepository collegeRepository;

    private Users getUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return usersRepository.findUsersByUserName(auth.getName());
    }

    @RequestMapping("/planServer/{id}")
    public String showPlans(ModelMap modelMap, @PathVariable int id) {
        Plan plan = planJpaRepository.getOne(id);
        Boolean hasReport = false;

        hasReport = true;
        modelMap.put("plan", plan);
        modelMap.put("hasReport", hasReport);

        modelMap.put("user", getUser());
        return "planServer";
    }

    @RequestMapping(value = "/planServerz", params = {"astekakil"})
    public String editASinglePlan(Plan plan, BindingResult bindingResult, HttpServletRequest request, ModelMap modelMap) {
        Integer id = Integer.parseInt(request.getParameter("astekakil"));
        whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();

        plan = planJpaRepository.getOne(id.intValue());

        modelMap.put("plan", plan);
        modelMap.put("whichOneIsClicked", whichOneIsClicked);

        modelMap.put("user", getUser());
        return "editPlan";
    }

    @RequestMapping(value = "/planServerz", params = {"mirmera"})
    public String addMirmeraForAPlan(Plan plan, BindingResult bindingResult, HttpServletRequest request, ModelMap modelMap) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        Users user = usersRepository.findUsersByUserName(auth.getName());

        Integer id = Integer.parseInt(request.getParameter("mirmera"));
        whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();

        plan = planJpaRepository.getOne(id.intValue());

        modelMap.put("plan", plan);
        modelMap.put("whichOneIsClicked", whichOneIsClicked);
        modelMap.put("user", user);

        modelMap.put("user", getUser());
        return "addMirmeraToAPlan";
    }

    @RequestMapping(value = "/planServerz", params = {"adisEkid"})
    public String createANewPlan(Plan plan, BindingResult bindingResult, HttpServletRequest request, ModelMap modelMap) {
        int dotPosition = request.getParameter("adisEkid").indexOf('.');
        int senderId = Integer.parseInt(request.getParameter("adisEkid").substring(0, dotPosition));
        int receiverId = Integer.parseInt(request.getParameter("adisEkid").substring(dotPosition + 1));

        plan.setSenderGroupId(senderId);
        plan.setReceiverGroupId(receiverId);

        whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();
        modelMap.put("whichOneIsClicked", whichOneIsClicked);
        modelMap.put("user", getUser());
        return "planServerNewTwo";
    }

    @RequestMapping(value = "/planServerz", params = {"atifa"})
    public String deleteASinglePlan(HttpServletRequest request) {


        Integer id = Integer.parseInt(request.getParameter("atifa"));
        Plan plan = planJpaRepository.getOne(id.intValue());

        //delete the report first;
        for (Report report : reportJpaRepository.findAll()) {
            if(report.getPlanId() == id.intValue()) {
                reportJpaRepository.delete(report);
                break;
            }
        }

        if (plan.isNewPlan())
            decrementViewedPlans(plan);

        //then delete the report;
        planJpaRepository.deleteById(id.intValue());

        return "redirect:/plansList";
    }

    @RequestMapping(value = "/planServerz", params = {"showAReport"})
    public String showReports(HttpServletRequest request, ModelMap modelMap) {
        Integer planId = Integer.parseInt(request.getParameter("showAReport"));

        Report report = reportJpaRepository.findByPlanId(planId);
        modelMap.put("report", report);

        modelMap.put("user", getUser());
        return "reportServer";
    }

    @RequestMapping(value = "/planServerz", params = {"adisReport"})
    public String newReport(HttpServletRequest request) {

        Integer id = Integer.parseInt(request.getParameter("adisReport"));

        return "redirect:/reportServerNewTwo/" + id;
    }

    public void decrementViewedPlans(Plan plan) {
        if (plan.isNewPlan()) {         //When a sender clicks the plan he get into this if clause, but can not do any thing;
            if (getUser().isInDevelopment() && (getUser().getDevelopmentId().getId() == plan.getReceiverGroupId())) {          //if the user(receiver) is a development leader;
                if (getUser().getDevelopmentId().getNewPlans() > 0) {
                    getUser().getDevelopmentId().decrementNewPlans();
                    developmentRepository.save(getUser().getDevelopmentId());
                    plan.setNewPlan(false);
                    planJpaRepository.save(plan);
                }
            }
            if (getUser().isDepartmentHead() && (getUser().getHeadDepartmentId().getId() == plan.getReceiverGroupId())) {     //if the user(receiver) is department head;
                if (getUser().getHeadDepartmentId().getNewPlans() > 0) {
                    getUser().getHeadDepartmentId().decrementNewPlans();
                    departmentRepository.save(getUser().getHeadDepartmentId());
                    plan.setNewPlan(false);
                    planJpaRepository.save(plan);
                }
            }
            if (getUser().isDean() && (getUser().getDeanId().getId() == plan.getReceiverGroupId())) {
                if (getUser().getDeanId().getNewPlans() > 0) {
                    getUser().getDeanId().decrementNewPlans();
                    collegeRepository.save(getUser().getDeanId());
                    plan.setNewPlan(false);
                    planJpaRepository.save(plan);
                }
            }
        }
    }
}
