package com.example.new1.Repository;

import com.example.new1.Model.Academic.DevelopmentGroup;
import com.example.new1.Model.Academic.Staff;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DevelopmentRepository extends JpaRepository<DevelopmentGroup, Integer> {

    DevelopmentGroup findById(int id);

    List<DevelopmentGroup> findByDepartment_Id(int id);

    List<DevelopmentGroup> findByLeader_Id(int id);

}
