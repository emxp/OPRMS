package com.example.new1.Repository.planRepositories;

import com.example.new1.Model.planRelated.Plan;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import java.awt.print.Pageable;
import java.util.List;

@Component
public interface PlanJpaRepository extends JpaRepository<Plan, Integer> {

    Plan findById(int id);
    List<Plan> findByReceiverGroupIdAndNewPlanIsTrue(int receiverGroupId);
//
//    List<Plan> findByReceiverGroupId(int receiverGroupId);
}
