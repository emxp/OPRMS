package com.example.new1.Controller.staff;

import com.example.new1.Model.Security.Users;
import com.example.new1.Repository.Security.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ExampleController {

    @Autowired
    UsersRepository usersRepository;

    private Users getUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return usersRepository.findUsersByUserName(auth.getName());
    }

    @RequestMapping("/examples")
    public String showExamples(ModelMap modelMap) {
        modelMap.put("user", getUser());
        return "example";
    }

}
