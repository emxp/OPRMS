package com.example.new1.Model.reportRelated;

import org.hibernate.validator.constraints.Length;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "occurred_problems", catalog = "test")
public class OccurredProblem {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private int id;

    @NotEmpty(message = "መረጃ ማስገባት አለብዎት!")
    @Column(columnDefinition = "TEXT")
    private String problems;

    @NotEmpty(message = "መረጃ ማስገባት አለብዎት!")
    @Column(columnDefinition = "TEXT")
    private String solutions;

    @Column(name = "report_id", insertable = false, updatable = false)
    private int reportId;

    public OccurredProblem() {
    }

//  uncomment this constructor only if problems around occurredProblems happen;
//    public OccurredProblem(int id, String problems, String solutions) {
//        this.id = id;
//        this.problems = problems;
//        this.solutions = solutions;
//    }

    public OccurredProblem(String problems, String solutions) {
        this.problems = problems;
        this.solutions = solutions;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getProblems() {
        return problems;
    }

    public void setProblems(String problems) {
        this.problems = problems;
    }

    public String getSolutions() {
        return solutions;
    }

    public void setSolutions(String solutions) {
        this.solutions = solutions;
    }

    public int getReportId() {
        return reportId;
    }

    public void setReportId(int reportId) {
        this.reportId = reportId;
    }
}
