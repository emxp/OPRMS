package com.example.new1.Controller.admin;

import com.example.new1.Model.Academic.*;
import com.example.new1.Model.Security.Users;
import com.example.new1.Repository.CollegeRepository;
import com.example.new1.Repository.DeanRepository;
import com.example.new1.Repository.DepHeadRepository;
import com.example.new1.Repository.Security.RoleRepository;
import com.example.new1.Repository.Security.UsersRepository;
import com.example.new1.Repository.StaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Controller
@RequestMapping(value = "/admin")
@PreAuthorize("hasAnyRole('ADMIN')")
public class adminDeanController {

    @Autowired
    private DeanRepository deanRepository;
    @Autowired
    private StaffRepository staffRepository;
    @Autowired
    private CollegeRepository collegeRepository;
    @Autowired
    private DepHeadRepository depHeadRepository;
    @Autowired
    private UsersRepository usersRepository;
    @Autowired
    private RoleRepository roleRepository;

    @RequestMapping("/deans")
    public String listDeans(ModelMap modelMap){
        List<Dean> allDeans= deanRepository.findAllByOrOrderByCollegeAsc();
        modelMap.put("deans", allDeans);
        return "admin/adminDean";
    }

    @RequestMapping(value = "/addDean")
    public String addDean(Model model){
        List<College> colleges = getNonDeanColleges();
        List<Staff> staffs = getNonDeanStaffs();
        if(colleges.isEmpty()){
            List<Dean> allDeans= deanRepository.findAllByOrOrderByCollegeAsc();
            model.addAttribute("deans", allDeans);
            model.addAttribute("isEmpty", true);
            return "admin/adminDean";
        }else if(staffs.isEmpty()){
            List<Dean> allDeans= deanRepository.findAllByOrOrderByCollegeAsc();
            model.addAttribute("deans", allDeans);
            model.addAttribute("isStaffEmpty", true);
            return "admin/adminDean";
        }else {
            model.addAttribute("colleges", colleges);
            model.addAttribute("staffs", staffs);
            model.addAttribute("dean", new Dean());
            model.addAttribute("isEdit", false);
            return "admin/editDean";
        }
    }

    public List<College> getNonDeanColleges(){
        List<College> colleges = collegeRepository.findAllByOrderByCollege_NameAsc();
        List<Dean> deans = deanRepository.findAll();
        List<College> deanCollege = new ArrayList<>();
        for (int i=0; i<deans.size(); i++){
            deanCollege.add(deans.get(i).getCollege());
        }
        for (int i=0; i<colleges.size(); i++) {
            if(deanCollege.contains(colleges.get(i))){
                colleges.remove(colleges.get(i));
                i--;        //because when item remove the structure of list is changed. so we have to move back at every remove!
            }
        }
        return colleges;
    }
    public List<Staff> getNonDeanStaffs(){
        List<Staff> staffs = staffRepository.findAllByOrderByFirst_NameAsc();
        List<Dean> deans = deanRepository.findAll();
        List<DepartmentHead> departmentHeads = depHeadRepository.findAll();
        List<Staff> deanStaff = new ArrayList<>();
        for (int i=0; i<deans.size(); i++){
            deanStaff.add(deans.get(i).getStaff());
        }
        for (int i=0; i<departmentHeads.size(); i++){
            deanStaff.add(departmentHeads.get(i).getStaff());
        }
        for (int i=0; i<staffs.size(); i++) {
            if(deanStaff.contains(staffs.get(i))){
                staffs.remove(staffs.get(i));
                i--;        //because when item remove the structure of list is changed. so we have to move back at every remove!
            }
        }
        return staffs;
    }
    public List<Staff> getNonDeanStaffs(College college){
        List<Staff> staffs = staffRepository.findAllByOrderByFirst_NameAsc();
        List<Dean> deans = deanRepository.findAll();
        List<DepartmentHead> departmentHeads = depHeadRepository.findAll();
        List<Staff> deanStaff = new ArrayList<>();
        for (int i=0; i<deans.size(); i++){
            deanStaff.add(deans.get(i).getStaff());
        }
        for (int i=0; i<departmentHeads.size(); i++){
            deanStaff.add(departmentHeads.get(i).getStaff());
        }
        for (int i=0; i<staffs.size(); i++) {
            if(deanStaff.contains(staffs.get(i)) || staffs.get(i).getDepartment().getCollege().getId() != college.getId()){
                staffs.remove(staffs.get(i));
                i--;        //because when item remove the structure of list is changed. so we have to move back at every remove!
            }
        }
        return staffs;
    }

    @RequestMapping(value = "/{id}/editDean")
    public String editDean(@PathVariable int id, Model model){
        Dean dean = deanRepository.findById(id);
        model.addAttribute("dean", dean);
        College college = dean.getCollege();
        model.addAttribute("college", college);
        List<Staff> staffs = getNonDeanStaffs(college);
        staffs.add(dean.getStaff());
        model.addAttribute("staffs", staffs);

        model.addAttribute("isEdit", true);
        return "admin/editDean";
    }

    @PostMapping(value = {"/deans/dean", "/deans/dean/{id}"})
    public String addDepartment(@Valid Dean dean, BindingResult bindingResult, Model model){
        if(dean.getStaff().getDepartment().getCollege().getId() != dean.getCollege().getId()){
            List<College> colleges = getNonDeanColleges();
            List<Staff> staffs = getNonDeanStaffs();

            model.addAttribute("colleges", colleges);
            model.addAttribute("staffs", staffs);
            model.addAttribute("dean", new Dean());
            model.addAttribute("isEdit", false);

            model.addAttribute("staff", dean.getStaff());
            model.addAttribute("college", dean.getCollege());

            model.addAttribute("cannotDean", true);
            return "admin/editDean";
        }

        if(dean.getId() != 0){
            Dean dean1 = deanRepository.findById(dean.getId());

            Users user = usersRepository.findByStaff(dean1.getStaff());
            user.getRoles().remove(roleRepository.findByRole("DEAN"));

            if(user.getRoles().isEmpty()){
                usersRepository.delete(user);
            }
        }

        if(usersRepository.findByStaff(dean.getStaff()) == null){
            Users user = new Users(1, dean.getStaff().getUserName(), dean.getStaff().getPassword(), dean.getStaff());
            user.setRole(roleRepository.findByRole("DEAN"));
            user.setDeanId(dean.getCollege());
            usersRepository.save(user);
        } else if(usersRepository.findByStaff(dean.getStaff()).getStaff() == dean.getStaff()){
            Users users = usersRepository.findByStaff(dean.getStaff());
            users.setRole(roleRepository.findByRole("DEAN"));
            users.setDeanId(dean.getCollege());
        }

        deanRepository.save(dean);
        return "redirect:/admin/deans";
    }

    @RequestMapping(value = "/{id}/deleteDean")
    public String deleteDepartment(@PathVariable int id) {

        Dean dean = deanRepository.findById(id);

        Users user = usersRepository.findByStaff(dean.getStaff());
        user.getRoles().remove(roleRepository.findByRole("DEAN"));
        user.setDeanId(null);

        if(user.getRoles().isEmpty()){
            usersRepository.delete(user);
        }

        deanRepository.deleteById(id);
        return "redirect:/admin/deans";
    }
}
