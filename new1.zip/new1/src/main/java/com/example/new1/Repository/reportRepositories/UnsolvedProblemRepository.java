package com.example.new1.Repository.reportRepositories;


import com.example.new1.Model.reportRelated.UnsolvedProblem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UnsolvedProblemRepository extends JpaRepository<UnsolvedProblem, Integer> {

}
