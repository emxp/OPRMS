package com.example.new1.Controller.reportRelated;

import com.example.new1.Model.Security.Users;
import com.example.new1.Model.planRelated.*;
import com.example.new1.Model.reportRelated.*;
import com.example.new1.Repository.CollegeRepository;
import com.example.new1.Repository.DepartmentRepository;
import com.example.new1.Repository.DevelopmentRepository;
import com.example.new1.Repository.Security.UsersRepository;
import com.example.new1.Repository.general.ScrollRepository;
import com.example.new1.Repository.planRepositories.PlanJpaRepository;
import com.example.new1.Repository.reportRepositories.OccurredProblemRepository;
import com.example.new1.Repository.reportRepositories.ReportJpaRepository;
import com.example.new1.Repository.reportRepositories.UnsolvedProblemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@Controller
@PreAuthorize("hasAnyRole('ONE_TO_FIVE', 'DEVELOPMENT', 'DEPARTMENT', 'DEAN')")
public class NewReportController {

    @Autowired
    ReportJpaRepository reportJpaRepository;

    @Autowired
    PlanJpaRepository planJpaRepository;

    @Autowired
    OccurredProblemRepository occurredProblemRepository;

    @Autowired
    UnsolvedProblemRepository unsolvedProblemRepository;

    @Autowired
    ScrollRepository scrollRepository;

    List<String> whichOneIsClicked = new ArrayList<>();

    @Autowired
    UsersRepository usersRepository;

    @Autowired
    DevelopmentRepository developmentRepository;

    @Autowired
    DepartmentRepository departmentRepository;

    @Autowired
    CollegeRepository collegeRepository;

    private Users getUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return usersRepository.findUsersByUserName(auth.getName());
    }

    @RequestMapping({"/reportServerNewTwo/{id}", "/addReportRow"})
    public String showNewReportFromPlan(Report report, BindingResult bindingResult, @PathVariable int id, ModelMap modelMap) {
        whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();
        Plan plan = planJpaRepository.getOne(id);

        initializeAReport(report, plan);

        report.setSenderGroupId(plan.getSenderGroupId());
        report.setReceiverGroupId(plan.getReceiverGroupId());

        modelMap.put("whichOneIsClicked", whichOneIsClicked);
        modelMap.put("user", getUser());
        return "reportServerNewTwo";
    }

    @RequestMapping(value = {"/addReportRow", "/addReportEditRow"}, params = {"newReportline"})
    public String addOccurredRows(Report report, BindingResult bindingResult, HttpServletRequest request, ModelMap modelMap) {
        whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();
        int newOrEdit = Integer.valueOf(request.getParameter("newReportline").substring(0, 1)).intValue();
        int dotPosition = request.getParameter("newReportline").indexOf('.');
        String occurredOrUnsolved = request.getParameter("newReportline").substring(1, dotPosition);
        Integer thePlanId = Integer.valueOf(request.getParameter("newReportline").substring(dotPosition + 1));


        Plan plan = planJpaRepository.findById(thePlanId.intValue());

        report.setPlan(plan);
        report.setPlanId(thePlanId.intValue());

        switch (occurredOrUnsolved) {
            case "occurred":
                report.getOccurredProblems().add(new OccurredProblem());
                whichOneIsClicked.set(5, "theClickedBtn");
                break;
            case "unsolved":
                report.getUnsolvedProblems().add(new UnsolvedProblem());
                whichOneIsClicked.set(6, "theClickedBtn");
                break;
            default:
                break;
        }
        modelMap.put("whichOneIsClicked", whichOneIsClicked);
        modelMap.put("user", getUser());

        //here 1 means the user is adding an occurredProblem row at the reportServerNewTwo.html, but 2 means he is adding a row in the editReport.html
        return (newOrEdit == 1 ? "reportServerNewTwo" : "editReport");
    }

    @RequestMapping(value = "/addReportRow", params = {"saveAllData"})
    public String saveAllPlans(@Valid Report report, BindingResult bindingResult, HttpServletRequest request, ModelMap modelMap) {
        if (bindingResult.hasErrors()) {
            Integer planId = Integer.valueOf(request.getParameter("saveAllData"));
            whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();
            Plan plan = planJpaRepository.getOne(planId.intValue());
            initializeAReport(report, plan);

            modelMap.put("whichOneIsClicked", whichOneIsClicked);
            modelMap.put("user", getUser());
            return "reportServerNewTwo";
        }
        reportJpaRepository.save(report);

        incrementNewlyCreatedReports(report.getReceiverGroupId());

        return "redirect:/reportsList";
    }

    @RequestMapping(value = {"/addReportRow", "/addReportEditRow"}, params = {"droplineRep"})
    public String removeRepRow(Report report, BindingResult bindingResult, HttpServletRequest request, ModelMap modelMap) {
        whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();

        String newOrEdit = request.getParameter("droplineRep").substring(0, 1); //this is just a separator
        int dotPosition = request.getParameter("droplineRep").indexOf('.'); //this is just a separator
        int questionMarkPsn = request.getParameter("droplineRep").indexOf('?');  //this is just a separator

        Integer thePlanId = Integer.valueOf(request.getParameter("droplineRep").substring(2, dotPosition));
        Integer toBeRemovedId = Integer.valueOf(request.getParameter("droplineRep").substring(dotPosition + 1, questionMarkPsn));
        Integer toBeRemovedIndex = Integer.valueOf(request.getParameter("droplineRep").substring(questionMarkPsn + 1));

        System.out.println("\n123qqqqqqqqqqqq " + thePlanId.intValue());
        System.out.println("123QQQQQQQQQQQQ " + toBeRemovedId.intValue());



        switch (request.getParameter("droplineRep").substring(1, 2)) {
            case "1":       //for report1 only
                if (toBeRemovedId != 0) {   //the report1 is not new. i.e it is already there;
                    for (Report1 report1 : report.getReport1s()) {
                        if (report1.getId() == toBeRemovedId) {
                            report1.setPercentage(0);
                            report1.setIfNotWhy("");
                            break;
                        }
                    }
                } else {                //if the report is to be written; i.e not written already;
                    report.getReport1s().get(toBeRemovedIndex).setPercentage(0);
                    report.getReport1s().get(toBeRemovedIndex).setIfNotWhy("");
                }
                whichOneIsClicked.set(0, "theClickedBtn");
                break;
            case "2":   //for report2 only
                if (toBeRemovedId != 0) {   //the report2 is not new. i.e it is already there;
                    for (Report2 report2 : report.getReport2s()) {
                        if (report2.getId() == toBeRemovedId) {
                            report2.setPercentage(0);
                            report2.setIfNotWhy("");
                            break;
                        }
                    }
                } else {                //if the report is to be written; i.e not written already;
                    report.getReport2s().get(toBeRemovedIndex).setPercentage(0);
                    report.getReport2s().get(toBeRemovedIndex).setIfNotWhy("");
                }
                whichOneIsClicked.set(1, "theClickedBtn");
                break;
            case "3":       //for report3 only
                if (toBeRemovedId != 0) {   //the report3 is not new. i.e it is already there;
                    for (Report3 report3 : report.getReport3s()) {
                        if (report3.getId() == toBeRemovedId) {
                            report3.setPercentage(0);
                            report3.setIfNotWhy("");
                            break;
                        }
                    }
                } else {                //if the report is to be written; i.e not written already;
                    report.getReport3s().get(toBeRemovedIndex).setPercentage(0);
                    report.getReport3s().get(toBeRemovedIndex).setIfNotWhy("");
                }
                whichOneIsClicked.set(2, "theClickedBtn");
                break;
            case "4":       //for report4 only
                if (toBeRemovedId != 0) {   //the report4 is not new. i.e it is already there;
                    for (Report4 report4 : report.getReport4s()) {
                        if (report4.getId() == toBeRemovedId) {
                            report4.setPercentage(0);
                            report4.setIfNotWhy("");
                            break;
                        }
                    }
                } else {                //if the report is to be written; i.e not written already;
                    report.getReport4s().get(toBeRemovedIndex).setPercentage(0);
                    report.getReport4s().get(toBeRemovedIndex).setIfNotWhy("");
                }
                whichOneIsClicked.set(3, "theClickedBtn");
                break;
            case "5":       //for report5 only
                if (toBeRemovedId != 0) {   //the report5 is not new. i.e it is already there;
                    for (Report5 report5 : report.getReport5s()) {
                        if (report5.getId() == toBeRemovedId) {
                            report5.setPercentage(0);
                            report5.setIfNotWhy("");
                            break;
                        }
                    }
                } else {                //if the report is to be written; i.e not written already;
                    report.getReport5s().get(toBeRemovedIndex).setPercentage(0);
                    report.getReport5s().get(toBeRemovedIndex).setIfNotWhy("");
                }
                whichOneIsClicked.set(4, "theClickedBtn");
                break;
            default:
                break;
        }

        Plan plan = planJpaRepository.findById(thePlanId.intValue());

        report.setPlan(plan);
        report.setPlanId(thePlanId.intValue());

        modelMap.put("whichOneIsClicked", whichOneIsClicked);
        modelMap.put("user", getUser());
        //here n means the user is CLEARING a report row at the reportServerNewTwo.html, but 'e' means he is clearing a row in the editReport.html
        return (newOrEdit.equals("n") ? "reportServerNewTwo" : "editReport");
    }

    @RequestMapping(value = {"/addReportRow", "/addReportEditRow"}, params = {"dropOPline"})
    public String removeOPRow(Report report, BindingResult bindingResult, HttpServletRequest request, ModelMap modelMap) {
        whichOneIsClicked = scrollRepository.populateWhichOneIsClicked();
        String newOrEdit = request.getParameter("dropOPline").substring(0, 1);

        int dotPosition = request.getParameter("dropOPline").indexOf('.');      //this is just a separator
        int questionMarkPsn = request.getParameter("dropOPline").indexOf('?');  //this is just a separator

        Integer toBeRemovedIndex = Integer.valueOf(request.getParameter("dropOPline").substring(2, dotPosition));
        Integer toBeRemovedId = Integer.valueOf(request.getParameter("dropOPline").substring(dotPosition + 1, questionMarkPsn));
        Integer thePlanId = Integer.valueOf(request.getParameter("dropOPline").substring(questionMarkPsn + 1));

        System.out.println("123QQQQQQQQQQQQ " + toBeRemovedId.intValue());
        System.out.println("\n123qqqqqqqqqqqq " + toBeRemovedIndex.intValue());


        Plan plan = planJpaRepository.findById(thePlanId.intValue());

        report.setPlan(plan);
        report.setPlanId(thePlanId.intValue());

        switch (request.getParameter("dropOPline").substring(1, 2)) {
            case "1":       //if the OccurredProblems is to be removed
                if (toBeRemovedId.intValue() == 0) {
                    report.getOccurredProblems().remove(toBeRemovedIndex.intValue());
                    System.out.println("yyyyy");
                }
                else {
                    report.getOccurredProblems().remove(toBeRemovedIndex.intValue());
                    occurredProblemRepository.deleteById(toBeRemovedId);
                    System.out.println("zzzzz");
                }
                whichOneIsClicked.set(5, "theClickedBtn");
                break;
            case "2":     //if the UnsolvedProblems is to be solved;
                if (toBeRemovedId.intValue() == 0) {
                    report.getUnsolvedProblems().remove(toBeRemovedIndex.intValue());
                    System.out.println("yyyyyunsolved");
                }
                else {
                    report.getUnsolvedProblems().remove(toBeRemovedIndex.intValue());
                    unsolvedProblemRepository.deleteById(toBeRemovedId);
                    System.out.println("zzzzzunsolved");
                }
                whichOneIsClicked.set(6, "theClickedBtn");
                break;
            default:
                break;
        }
        modelMap.put("whichOneIsClicked", whichOneIsClicked);
        modelMap.put("user", getUser());
        //here 'n' means the user is removing an occurred or unsolved row at the reportServerNew.html, but 'e' means he's doing that in the editReport.html
        return (newOrEdit.equals("n") ? "reportServerNewTwo" : "editReport");
    }

    private void initializeAReport(Report report, Plan plan) {
        //setting the plan and most importantly the planId for the NEWLY created report;
        report.setPlan(plan);
        report.setPlanId(plan.getId());

        //adding reports equally with the number of plans that have been written
        for (Plan1 plan1 : plan.getPlan1s()) {
            Report1 report1 = new Report1(plan1.getId(), plan1);
            report.getReport1s().add(report1);
        }

        for (Plan2 plan2 : plan.getPlan2s()) {
            Report2 report2 = new Report2(plan2.getId(), plan2);
            report.getReport2s().add(report2);
        }

        for (Plan3 plan3 : plan.getPlan3s()) {
            Report3 report3 = new Report3(plan3.getId(), plan3);
            report.getReport3s().add(report3);
        }

        for (Plan4 plan4 : plan.getPlan4s()) {
            Report4 report4 = new Report4(plan4.getId(), plan4);
            report.getReport4s().add(report4);
        }

        for (Plan5 plan5 : plan.getPlan5s()) {
            Report5 report5 = new Report5(plan5.getId(), plan5);
            report.getReport5s().add(report5);
        }
    }

    public void incrementNewlyCreatedReports(Integer receiverId) {
        if (((getUser().getOneToFiveId() != null) && (getUser().getOneToFiveId().getDevelopmentGroup() != null))) {     //if the sender is 125 leader AND Only INVOLVED(not leading) in some development group and sending to the development group; Or works also for a development leader also, who is sending to the development that he is in or he leads;
            if (getUser().getOneToFiveId().getDevelopmentGroup().getId() == receiverId) {
                getUser().getOneToFiveId().getDevelopmentGroup().incrementNewReports();
                developmentRepository.save(getUser().getOneToFiveId().getDevelopmentGroup());
            }
        }
        if (getUser().getDevelopmentId() != null) {     //if the sender is a development leader and he is sending to the department that his development is in;
            if (getUser().getDevelopmentId().getDepartment().getId() == receiverId) {
                getUser().getDevelopmentId().getDepartment().incrementNewReports();
                departmentRepository.save(getUser().getDevelopmentId().getDepartment());
            }
        }
        if (getUser().getHeadDepartmentId() != null) {     //if the sender is a department head and he is sending to the college his department is in;
            if (getUser().getHeadDepartmentId().getCollege().getId() == receiverId) {
                getUser().getHeadDepartmentId().getCollege().incrementNewReports();
                collegeRepository.save(getUser().getHeadDepartmentId().getCollege());
            }
        }
    }

}
